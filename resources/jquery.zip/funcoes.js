//m�scara para valores em R$

function mascaraMoeda(objTextBox, SeparadorMilesimo, SeparadorDecimal, e){
    var sep = 0;
    var key = '';
    var i = j = 0;
    var len = len2 = 0;
    var strCheck = '0123456789';
    var aux = aux2 = '';
    var whichCode = (window.Event) ? e.which : e.keyCode;
    if (whichCode == 13) return true;
    key = String.fromCharCode(whichCode); // Valor para o c�digo da Chave
    if (strCheck.indexOf(key) == -1) return false; // Chave inv�lida
    len = objTextBox.value.length;
    var max = objTextBox.maxLength;
    
    if (objTextBox.value.length == max){
    	return;
    }
    for(i = 0; i < len; i++)
        if ((objTextBox.value.charAt(i) != '0') && (objTextBox.value.charAt(i) != SeparadorDecimal)) break;
    aux = '';
    for(; i < len; i++)
        if (strCheck.indexOf(objTextBox.value.charAt(i))!=-1) aux += objTextBox.value.charAt(i);
    aux += key;
    len = aux.length;
    if (len == 0) objTextBox.value = '';
    if (len == 1) objTextBox.value = '0'+ SeparadorDecimal + '0' + aux;
    if (len == 2) objTextBox.value = '0'+ SeparadorDecimal + aux;
    if (len > 2) {
        aux2 = '';
        for (j = 0, i = len - 3; i >= 0; i--) {
            if (j == 3) {
                aux2 += SeparadorMilesimo;
                j = 0;
            }
            aux2 += aux.charAt(i);
            j++;
        }
        objTextBox.value = '';
        len2 = aux2.length;
        for (i = len2 - 1; i >= 0; i--)
        objTextBox.value += aux2.charAt(i);
        objTextBox.value += SeparadorDecimal + aux.substr(len - 2, len);
    }
    return false;
}

	function Moeda(num){
	  x = 0;
	  
	  if(num < 0) { num = Math.abs(num);   x = 1; }
	  
	  if(isNaN(num)) num = "0";
	  cents = Math.floor((num*100+0.5)%100);
	    num = Math.floor((num*100+0.5)/100).toString();
	 
	  if(cents < 10) cents = "0" + cents;
	    for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
	  num = num.substring(0,num.length-(4*i+3))+'.'+num.substring(num.length-(4*i+3));
	                 
	  ret = num + ',' + cents; 
	  if (x == 1) 
	  ret = '-' + ret;
	                
	  return ret;
	}
	
	function MaxLengthTextArea(id,MaxLength,contador) {
          obj = document.getElementById(id);
          if (MaxLength !=0) {
                 if (obj.value.length > MaxLength)  {
                        obj.value = obj.value.substring(0, MaxLength);
                        }
          }
          document.getElementById(contador).value = obj.value.length + '/'+MaxLength;
   }
/******************************************************************/
function isCpf(v) {
	var s = null;
	var r = null;
	// N�o verifica caso o usu�rio n�o digite nenhum caracter.
	if (v.length == 0) {
		return true;
	}
	for ( var i = 0, digit; digit = v[i]; i++) {
		if (isNaN(digit)) {
			v = v.replace(digit, '');
		}
	}
	if (v.length != 11
			|| v
					.match(/1{11}|2{11}|3{11}|4{11}|5{11}|6{11}|7{11}|8{11}|9{11}|0{11}/))
		return false;
	s = 0;
	for ( var i = 0; i < 9; i++)
		s += parseInt(v.charAt(i)) * (10 - i);
	r = 11 - (s % 11);
	if (r == 10 || r == 11)
		r = 0;
	if (r != parseInt(v.charAt(9)))
		return false;
	s = 0;
	for ( var i = 0; i < 10; i++)
		s += parseInt(v.charAt(i)) * (11 - i);
	r = 11 - (s % 11);
	if (r == 10 || r == 11)
		r = 0;
	if (r != parseInt(v.charAt(10)))
		return false;
	return true;
}

function isCnpj(v) {
	var dig1 = 0;
	var dig2 = 0;
	var x;
	var Mult1 = '543298765432';
	var Mult2 = '6543298765432';
	// N�o verifica caso o usu�rio n�o digite nenhum caracter.
	if (v.length == 0) {
		return true;
	}
	for ( var i = 0, digit; digit = v[i]; i++) {
		if (isNaN(digit)) {
			v = v.replace(digit, '');
		}
	}
	for (x = 0; x <= 11; x++) {
		dig1 = dig1
				+ (parseInt(v.slice(x, x + 1)) * parseInt(Mult1.slice(x, x + 1)));
	}
	for (x = 0; x <= 12; x++) {
		dig2 = dig2
				+ (parseInt(v.slice(x, x + 1)) * parseInt(Mult2.slice(x, x + 1)));
	}
	dig1 = (dig1 * 10) % 11;
	dig2 = (dig2 * 10) % 11;
	if (dig1 == 10) {
		dig1 = 0;
	}
	if (dig2 == 10) {
		dig2 = 0;
	}
	if (dig1 != parseInt(v.slice(12, 13))) {
		return false;
	} else {
		if (dig2 != parseInt(v.slice(13, 14))) {
			return false;
		} else {
			return true;
		}
	}
}

function isRg(v) {
	for ( var i = 0, digit; digit = v[i]; i++) {
		if (isNaN(digit)) {
			v = v.replace(digit, '');
		}
	}
	return (v.match(/[0-9xX]{9}/));
	
	return ValIdentidade(v);
}

function isCep(v) {
	for ( var i = 0, digit; digit = v[i]; i++) {
		if (isNaN(digit)) {
			v = v.replace(digit, '');
		}
	}
	if (v.length < 8)
		return false;
	return (v.match(/[0-9]{8}/));
}

function isSenha(v, c) {
	if (v != '') {
		if (v == c) {
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}

function isTel(v) {
	for ( var i = 0, digit; digit = v[i]; i++) {
		if (isNaN(digit)) {
			v = v.replace(digit, '');
		}
	}
	if (v.length < 11) {
		return (v.match(/\d{7,11}/));
	} else {
		return false
	}
}

function isDia(v) {
	return isNumber(v) && v > 0 && v <= 31;
}
function isMes(v) {
	return isNumber(v) && v > 0 && v <= 12;
}

function isAno(v) {
	return isNumber(v) && v > 1900 && v <= 2100;
}


/*Fun��o que padroniza valor mon�tario*/
    function Valor(v){
		v=v.replace(/\D/g,"") //Remove tudo o que n�o � d�gito
        v=v.replace(/^([0-9]{3}\.?){3}-[0-9]{2}$/,"$1.$2");
        //v=v.replace(/(\d{3})(\d)/g,"$1,$2")
        v=v.replace(/(\d)(\d{2})$/,"$1,$2") //Coloca ponto antes dos 2 �ltimos digitos

        return v
	}



/**
 * Fun��o respons�vel por verificar a quantidade de registros selecionados pelo
 * usu�rio.
 * 
 * @param nomeForm
 *            Nome do formul�rio.
 * @param nomeCadastro
 *            Nome do cadastro. Exemplo: usu�rio, perfil, advogado, etc.
 * @param nomeBotao
 *            Nome da funcionalidade associada ao bot�o pressionado pelo
 *            usu�rio.
 */
function checkUncheckAll(theElement) {
	var theForm = theElement.form, z = 0;
	for (z = 0; z < theForm.length; z++) {
		if (theForm[z].type == 'checkbox' && theForm[z].name != 'todos') {
			theForm[z].checked = theElement.checked;
		}
	}
}

function checkUnchkAll(theElement) {
	var theForm = theElement.form, z = 0;
	for (z = 0; z < theForm.length; z++) {
		if (theForm[z].type == 'checkbox' && theForm[z].name != 'todos' && theForm[z].name != 'tudo') {
			theForm[z].checked = theElement.checked;
		}
	}
}
 
function checkUncheck(theElement,check) {
	for (z = 0; z < check.length; z++) {
		check[z].checked = theElement.checked;
	}
}

  function checkSelecionado(check){
  	if(check.length){
	  	for (z = 0; z < check.length; z++) {
			if(check[z].checked){
				return true;
			}
		}
	}else{
		if(check.checked){
	 		return true;
	 	}
	}
	return false;
  }

  function valueCheckSelecionado(check){
  	for (z = 0; z < check.length; z++) {
		if(check[z].checked){
			return check[z].value;
		}
	}
	return null;
  }
/************************************************************************************************
*************************************Verifica_CPF(campo)*****************************************
************************************************************************************************/
function Verifica_CPF(campo) {
 	var CPF = campo.value ; // Recebe o valor digitado no campo
  	if ( CPF == 11111111111 || CPF == 22222222222 || CPF == 33333333333 || CPF == 44444444444 || CPF == 55555555555 || CPF == 66666666666 || CPF == 77777777777 || CPF == 88888888888 || CPF == 99999999999 || CPF == 00000000000 ) {
    	alert("CPF inv�lido");
    	campo.value="";
    	campo.value="";
    	campo.focus();
  	}

	// Aqui come�a a checagem do CPF
  	var POSICAO, I, SOMA, DV, DV_INFORMADO;
  	var DIGITO = new Array(10);
  	DV_INFORMADO = CPF.substr(9, 2); // Retira os dois �ltimos d�gitos do n�mero informado

	// Desemembra o n�mero do CPF na array DIGITO
  	for (I=0; I<=8; I++) {
    	DIGITO[I] = CPF.substr( I, 1);
  	}

	// Calcula o valor do 10� d�gito da verifica��o
  	POSICAO = 10;
  	SOMA = 0;
  	for (I=0; I<=8; I++) {
    	SOMA = SOMA + DIGITO[I] * POSICAO;
     	POSICAO = POSICAO - 1;
  	}
 	DIGITO[9] = SOMA % 11;
 	if (DIGITO[9] < 2) {
    	DIGITO[9] = 0;
  	} else {
    	DIGITO[9] = 11 - DIGITO[9];
  	}

	// Calcula o valor do 11� d�gito da verifica��o
  	POSICAO = 11; 
  	SOMA = 0;
  	for (I=0; I<=9; I++) {
    	SOMA = SOMA + DIGITO[I] * POSICAO;
    	POSICAO = POSICAO - 1;
  	}
  	DIGITO[10] = SOMA % 11;
  	if (DIGITO[10] < 2) {
    	DIGITO[10] = 0;
  	} else {
    	DIGITO[10] = 11 - DIGITO[10];
  	}

	// Verifica se os valores dos d�gitos verificadores conferem
  	DV = DIGITO[9] * 10 + DIGITO[10];
  	if (DV != DV_INFORMADO) {
    	alert("CPF inv�lido");
    	campo.value="";
    	campo.focus();
    	return false;
  	} 
}

/************************************************************************************************
*************************************Rotina para Verificar CNPJ**********************************
************************************************************************************************/
function verifica_CNPJ(campo) {
	var txtCnpj = campo.value ;
	if (txtCnpj == 11111111111111 || txtCnpj == 22222222222222 || txtCnpj == 33333333333333 || txtCnpj == 44444444444444 || txtCnpj == 55555555555555 || txtCnpj == 66666666666666 || txtCnpj == 77777777777777 || txtCnpj == 888888888888888 || txtCnpj == 999999999999999 || txtCnpj == 00000000000000){
 		alert("CNPJ inv�lido");
	  	campo.value=""
    	campo.focus();
    	return false;
  	}
	var num1 = new initArray(14);
	if(txtCnpj == null) {
    	alert("CNPJ nulo");
	  	campo.value="";
	  	campo.focus();
    	return false;
  	}
  	if(txtCnpj.length != 14) {
    	alert("CNPJ diferente de 14 posi��es");
    	campo.value="";
    	campo.focus();
    	return false;
  	}
 	for (var i = 0 ; i < 14 ; i++) {
    	num1[i] = txtCnpj.substring(i, i+1);
  	}
  	digito13 = calculaDigito(13, num1);
  	digito14 = calculaDigito(14, num1);
  	if (num1[12]==(digito13) && num1[13]==(digito14)){
    	return true;  
  	} else {
    	alert("CNPJ incorreto");
    	campo.value="";
	    campo.focus();
    	return false;  
  	}
}

/************************************************************************************************
 Nome: campoNumerico
 Descricao: Testa o valor digitado para ver se � num�rico
 Parametros: evt - evento que chama a fun��o
 Retorno:
************************************************************************************************/

function campoNumerico(evt,campo) {
	evt = (evt) ? evt : window.event
	var digito = campo.value
  	if(SoNumeros(campo)==false) {
		alert ("Este campo s� aceita n�meros.");
    	return false;
  	}
	if (isNaN (digito)) {
		var mainString = campo.value
   		var param1 = 0
		var param2 = -1
		campo.value = mainString.slice(param1, param2)
		alert ("Este campo s� aceita n�meros.")
		campo.focus()
	}
}

function SoNumeros(campo) {
	//deixa s� possui numeros
	var valor = campo.value;
	var tam = valor.length;
	var naux = "0123456789";
	var aux = "";
	for (i=0;i<tam;i++) {
		comp = false;
		for (j=0;j<naux.length;j++) {
			if (valor.charAt(i) == naux.charAt(j)) { comp = true; }
		}
		if(comp == false) { 
	      campo.value = aux;
		} else {
		  aux = aux+''+valor.charAt(i);
		}
	}
	campo.value = aux;
	return true;
}

function RetSoNumeros(valor) {
	//retorna s� possui numeros
	var tam = valor.length;
	var naux = "0123456789";
	var aux = "";
	for (i=0;i<tam;i++) {
		comp = false;
		for (j=0;j<naux.length;j++) {
			if (valor.charAt(i) == naux.charAt(j)) { comp = true; }
		}
		if(comp == true) { 
		  aux = aux+''+valor.charAt(i);
		}
	}
	return aux;
}

/**
 * Compara duas datas.
 * 
 * @param date1 string no formato "dd/MM/yyy"
 * @param date2 string no formato "dd/MM/yyy"
 * @return 
 * 		 0 se forem iguais
 * 		 1 se date1 for maior que date2
 * 		-1 se date1 form menor que date2  
 */
function compareDate( date1, date2 ){

	var array = date1.split('/');
	var d1 = array[2]+array[1]+array[0];
	
	array = date2.split('/');
	var d2 = array[2]+preencheZeros(array[1],2,0)+preencheZeros(array[0],2,0);

	if( d1 > d2 ){
		return 1;
	}
	
	if( d1 < d2 ){
		return -1;
	}
	
	return 0;
}
     
function preencheZeros (n, len, padding){
   var sign = '', s = n;
 
   if (typeof n === 'number'){
      sign = n < 0 ? '-' : '';
      s = Math.abs (n).toString ();
   }
 
   if ((len -= s.length) > 0){
      s = Array (len + 1).join (padding || '0') + s;
   }
   return sign + s;
}

function dataMaiorAtual( date ){
	data = new Date();
	dataAtual = data.getDate()+"/"+(data.getMonth()+1)+"/"+data.getFullYear();

	if(compareDate(date.value,dataAtual)>0){
		alert("A Data informada n�o pode ser maior que a data atual.");
		return false;
	}
	return true;
}
function dataMaiorqueAtual( date ){
	data = new Date();
	dataAtual = data.getDate()+"/"+(data.getMonth()+1)+"/"+data.getFullYear();
var retorno=	compareDate(date.value,dataAtual);

if(retorno==0 ||retorno==-1){
		return false;
	}
	return true;
}



function dataMenorAtual( date ){
	data = new Date();
	dataAtual = data.getDate()+"/"+(data.getMonth()+1)+"/"+data.getFullYear();

	if(compareDate(date.value,dataAtual)<0){
		alert("A Data informada n�o pode ser menor que a data atual.");
		return false;
	}
	return true;
}
function hoje(){
	data = new Date();
	dataAtual = data.getDate()+"/"+(data.getMonth()+1)+"/"+data.getFullYear();

	return dataAtual;	
}

function formataData(data){
	splitData = data.split("-");
	return splitData[2]+"/"+splitData[1]+"/"+splitData[0];
}

function trim(obj1) {
	if (obj1.value == undefined) {
		str = obj1;
	} else {
		str = obj1.value;
	}

	while (str.charAt(0) == " ")
		str = str.substr(1, str.length - 1);

	while (str.charAt(str.length - 1) == " ")
		str = str.substr(0, str.length - 1);
	obj1.value = str;
	return str;
}

function estaVazio(obj) {
	if (obj == null || (obj.type == "text" || obj.type == "textarea")
			&& trim(obj) == '') {
		return true;
	} else if (obj.type == "file" && trim(obj) == '') {
		return true;
	} else {
		if (obj.type == 'select-multiple' && obj.length == 0) {
			return true;
		}
	}
	return false;
}


function FormataValor(fld, milSep, decSep, e) {
	var sep = 0;
	var key = '';
	var i = j = 0;
	var len = len2 = 0;
	var strCheck = '0123456789';
	var aux = aux2 = '';
	var whichCode = (window.Event) ? e.which : e.keyCode;
	if (whichCode == 13) return true;
		key = String.fromCharCode(whichCode);  // Valor para o c�digo da Chave
	if (strCheck.indexOf(key) == -1) return false;  // Chave inv�lida
		len = fld.value.length;
	for(i = 0; i < len; i++)
		if ((fld.value.charAt(i) != '0') && (fld.value.charAt(i) != decSep)) break;
	
	aux = '';
	for(; i < len; i++)
		if (strCheck.indexOf(fld.value.charAt(i))!=-1) aux += fld.value.charAt(i);
	
	aux += key;
	len = aux.length;
	if (len == 0) fld.value = '';
	if (len == 1) fld.value = '0'+ decSep + '0' + aux;
	if (len == 2) fld.value = '0'+ decSep + aux;
	if (len > 2) {
		aux2 = '';
		for (j = 0, i = len - 3; i >= 0; i--) {
			if (j == 3) {
				aux2 += milSep;
				j = 0;
			}
			aux2 += aux.charAt(i);
			j++;
		}
		fld.value = '';
		len2 = aux2.length;
		for (i = len2 - 1; i >= 0; i--)
			fld.value += aux2.charAt(i);
	
		fld.value += decSep + aux.substr(len - 2, len);
	}
	return false;
}

