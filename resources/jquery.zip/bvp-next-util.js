
(function ( $ ) {
	
	"use strict";
	
	//FUNÇÃO QUE CONVERTE DE MINUTES PARA MILESEGUNDOS
	function minutesToMillisec(minutes){
		return (minutes * (1000 * 60));				
	}	
 
	/**
	 * Método que obtem o elemento dentro do iframe
	 * $('[id iframe]').iframe('[element inside iframe]')
	 */
	$.fn.iframe = function(select){
		var iframe = $(this);
		return $(iframe.contents()).find(select);					
	};
	
	/**
	 * Método que mantem em sessao o usuario  
	 */
	$.fn.refreshSession = function(minutes){
		
		var urlRefresh		= $(this).attr('url');
		
		var milleseconds	= minutesToMillisec(minutes);
		
		var recallFunc		= function(){
			$.ajax({
				type: 		"POST",
				dataType:	"text",
				url: 		urlRefresh
			});					
		};	
		
		$(this).show();
		
		setInterval(recallFunc,milleseconds);										
	};
	/**
	 * Verifica se o elemento existe 
	 * $([element id]).exist([element])
	 */
	$.fn.exist = function(element){
		return $(this).length>0;
	};
	
	$.browserIsOldIE = function() {
		//return (!(window.ActiveXObject) && "ActiveXObject" in window);
		return $('html').is('.lt-ie7, .lt-ie8, .lt-ie9');		
    };	
       
    $.fn.showButton = function(){
    	var iframe = $(this);
    	$('.btn-voltar').hide();
    	iframe.load(function(){
    		$('.btn-voltar').show();
    	});
    };
    
    /**
     * verifica se o o navegador esta habilitado a receber cookies de terceiros
     */    
    $.fn.supported = function(param){ 
    	
    	var frame = $(this);
    	
    	$('.thirdPartyCookies')    		
    		.hide();
    	
    	var initial = {
			success:function(){},
			error:function(){}
    	};
    	
    	var config = jQuery.extend(true, initial, param);
    	
		var receiveMessage = function (evt) {
			if (evt.data === 'MM:3PCunsupported') {//'not supported'
				config.error('infoCookies');
			} else if (evt.data === 'MM:3PCsupported') {//'supported'
				config.success();
			} else{
				config.error();
			}					
		};
		
		try {
			
	        if (window.addEventListener) {
	            window.addEventListener('message', receiveMessage, false);
	        } else if (window.attachEvent) {
	            window.attachEvent('onmessage', receiveMessage);
	        }
			
		} catch (e) {
			console.log(e);
		}

	};

 
}( jQuery ));