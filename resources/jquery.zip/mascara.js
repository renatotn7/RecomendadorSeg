function criaMascara(_RefObjeto, _Modelo){
    var valorAtual = _RefObjeto.value;        
    var valorNumerico = '';
    var nIndexModelo = 0;
    var nIndexString = 0;
    var valorFinal = '';
    var adicionarValor = true;
    for (i=0;i<_Modelo.length;i++) {
      if (_Modelo.substr(i,1) != '#') {
          valorAtual = valorAtual.replace(_Modelo.substr(i,1),'');
      }
	}
    for (i=0;i<valorAtual.length;i++) {
      if (!isNaN(parseFloat(valorAtual.substr(i,1)))) {
          valorNumerico = valorNumerico + valorAtual.substr(i,1);
      }
	}
    for (i=0;i<_Modelo.length;i++){
      if (_Modelo.substr(i,1) == '#'){
        if (valorNumerico.substr(nIndexModelo,1) != ''){
          valorFinal = valorFinal + valorNumerico.substr(nIndexModelo,1);
          nIndexModelo++;nIndexString++;
        } else {
          adicionarValor = false;
        }
      } else {
        if (adicionarValor && valorNumerico.substr(nIndexModelo,1) != ''){
           valorFinal = valorFinal + _Modelo.substr(nIndexString,1);
           nIndexString++;
        }
	  }
    }
    _RefObjeto.value = valorFinal;
}

function ChecaData(data){ 
   var err = 0;
   string = data;
   if(string.length==0) {
      return true;
   }
   var valid = "0123456789/";
   var ok = "yes";
   var temp;

   for (var i=0; i< string.length; i++)  {
        temp = "" + string.substring(i, i+1);
        if (valid.indexOf(temp) == "-1") err = 1;
   }

   if (string.length != 10) err=1

   dia = string.substring(0, 2); // dia
   c = string.substring(2, 3);// '/'
   mes = string.substring(3, 5); // mes
   e = string.substring(5, 6);// '/'
   ano = string.substring(6, 10); // ano

   if (mes<1 || mes>12) err = 1;
   if (c != '/') err = 1;
   if (dia<1 || dia>31) err = 1;
   if (e != '/') err = 1;
   if (ano.length != 4) err = 1;
   if (mes==4 || mes==6 || mes==9 || mes==11)  {
        if (dia==31) err=1;
   }
   if (mes==2)   {
        var g=parseInt(ano/4);
        if (isNaN(g))  {
                err=1;
        }
        if (dia>29) err=1;
        if (dia==29 && ((ano/4)!=parseInt(ano/4))) err=1;
   }
   if (err==1)  {
        return false;
   }
   else  {
        return true;
   }
}

function testedata(data) {
	if (ChecaData(data.value)) {
		return true;
	} else {
		alert("Data inv�lida");
		data.select();
	}
}

function ChecaNum(){
    var ValidChar="#48;#49;#50;#51;#52;#53;#54;#55;#56;#57;";
    if (ValidChar.indexOf("#" + String(event.keyCode + ";")) == -1) { event.returnValue = false; }
}

function VerificaDia(campo) {
   var ret = true;
   var data = campo.value;
   if(data.length > 0) {
      ret = ChecaData(data);
   }
   if(ret == false) {
   	 alert("Data inv�lida.");
   	 campo.value = "";
   	 campo.focus();
   }
   return ret;
}

function VerificaDiaSemMSG(campo) {
   var ret = true;
   var data = campo.value;
   if(data.length > 0) {
      ret = ChecaData(data);
   }
   return ret;
}