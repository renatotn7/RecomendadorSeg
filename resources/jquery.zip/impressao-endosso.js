$.fn.loadMutiSelectID = function(param){
	var table = this;
	var count = 0;
	//Botï¿½o Origem
	$($(table).find('a').eq(0)).click(
		function(){
//			Add com Todos Marcados
			if($(table).find('select').eq(0).find('option[value=-1]:selected').length!=0){
//				alert($(table).find('select').eq(0).find('option[value=-1]:selected').length);
				if ($(table).find('select').eq(0).find('option[value=-1]:selected').length > 0) {
					$(table).find('select').eq(1).append($(table).find('select').eq(0).find('option[value!=-1]'));
					$(table).find('select').eq(0).find('option[value=-1]').removeAttr('selected');
						
					if(param!=undefined){
						var url_data = '';
						$(table).find('select').eq(1).find('option').each(
							function(count){
								if(count==0){
									url_data+='GruposSelecionadas='+this.value;
//									alert(url_data);
								}else{
									url_data+='&GruposSelecionadas='+this.value;
//									alert(url_data);
								}
							}
						);					
						$.ajax(
							{
								dataType:"post",
								url: param.url,
								data: url_data+'&idlink='+$($(table).find('a').eq(0)).attr("id"),
								success:function(pAjax){
									if(table.attr('id') == 'tabelaGrupo'){
										$(param.selectID).html(pAjax);
									}
								},
								error:function(e){
//			    					alert(e);
								}
							}
						);					
					}
				}				
			}else{ 
//				Add Marcadas sem Todos

//				alert($(table).find('select').eq(0).find('option[value!=-1]:selected').length);				
				if ($(table).find('select').eq(0).find('option[value!=-1]:selected').length > 0) {
					$(table).find('select').eq(1).append($(table).find('select').eq(0).find('option[value!=-1]:selected'));				
					$(table).find('select').eq(0).find('option[value=-1]').removeAttr('selected');
					
					if(param!=undefined){
						var url_data = '';
						$(table).find('select').eq(1).find('option[value!=-1]:selected').each(
							function(count){
								if(count==0){
									url_data+='GruposSelecionadas='+this.value;
//									alert(url_data);
								}else{
									url_data+='&GruposSelecionadas='+this.value;
//									alert(url_data);
								}
							}
						);
						$.ajax(
							{
								dataType:"post",
								url: param.url,
								data: url_data+'&idlink='+$($(table).find('a').eq(0)).attr("id"),
								success:function(pAjax){
									if(table.attr('id') == 'tabelaGrupo'){
										$(param.selectID).html(pAjax);
									}
								},
								error:function(e){
//									alert(e);
								}
							}
						);
						
					}
					
				}
					
			}				
			order(table);
		}
	);
//	Botï¿½o Destino
	$($(table).find('a').eq(1)).click(
		function(){
//			Remove com Todos Marcados

//			alert($(table).find('select').eq(1).find('option[value=-1]:selected').length);			
			if($(table).find('select').eq(1).find('option[value=-1]:selected').length!=0){
//				if($(table).find('select').eq(1).find('option[value=-1]:selected').length > 0){
					$(table).find('select').eq(0).append($(table).find('select').eq(1).find('option[value!=-1]'));
					$(table).find('select').eq(0).find('option[value=-1]').removeAttr('selected');
					
					if(param!=undefined){
						var url_data = '';
						$(table).find('select').eq(1).find('option').each(
							function(count){
//								alert('teste1');
								if(count==0){
									url_data+='GruposSelecionadas='+this.value;
//									alert(url_data);
								}else{
									url_data+='&GruposSelecionadas='+this.value;
//									alert(url_data);
								}
							}
						);
						$.ajax(
							{
								dataType:"post",
								url: param.url,
								data: url_data+'&idlink='+$($(table).find('a').eq(1)).attr("id"),
								success:function(pAjax){
									if(table.attr('id') == 'tabelaGrupo'){
										$(param.selectID).html(pAjax);
									}
								},
								error:function(e){
//									alert(e);
								}
							}
						);				
					}
//				}
			}else{
//				Remove Marcadas sem Todos

//				alert($(table).find('select').eq(1).find('option[value!=-1]:selected').length);				
				if($(table).find('select').eq(1).find('option[value!=-1]:selected').length > 0){
					$(table).find('select').eq(0).append($(table).find('select').eq(1).find('option[value!=-1]:selected'));
					$(table).find('select').eq(0).find('option[value=-1]').removeAttr('selected');
					
					if(param!=undefined){
						var url_data = '';
						$(table).find('select').eq(1).find('option').each(
							function(count){
//								alert('teste0');
								if(count==0){
//									alert($(table).find('select').eq(1).find('option[value=-1]:selected').length);
									if($(table).find('select').eq(0).find('option[value=-1]:selected').length!=0){
										url_data+='GruposSelecionadas='+this.value;
//										alert(url_data);
									}
								}else{
	 								url_data+='&GruposSelecionadas='+this.value;
//									alert(url_data);
								}
							}
						);
						$.ajax(
							{
								dataType:"post",
								url: param.url,
								data: url_data+'&idlink='+$($(table).find('a').eq(1)).attr("id"),
								success:function(pAjax){
									if(table.attr('id') == 'tabelaGrupo'){
										$(param.selectID).html(pAjax);
									}
								},
								error:function(e){
//									alert(e);
								}
							}
						);					
					}
				}
				
			}
			order(table);
		}
	);		
};

/**
 * Mï¿½todo responsï¿½vel na ordenaï¿½ï¿½o dos label dos objetos options dentro do select
 */
function order(pTable){
	var op = $(pTable).find('select').eq(0).find('option');
	op.sort(function(a, b) {         
		return parseInt(a.value) > parseInt(b.value) ? 1 : -1;     
	}) 	
	$(pTable).find('select').eq(0).html(op);
	op = $(pTable).find('select').eq(1).find('option');
	op.sort(function(a, b) {         
		return parseInt(a.value) > parseInt(b.value) ? 1 : -1;     
	}) 	
	$(pTable).find('select').eq(1).html(op);	
}

function enviar(){	
	var count = 0;
	var cod = 0;
	var form = document.forms[0];
	
	$("#listaGruposSelecionadas option").each(function(){
	  $(this).attr("selected","selected");		  
	  //alert($(this).val());
	});
    
	$("#listaApolicesSelecionadas option").each(function(){
		$(this).attr("selected","selected");
		//alert($(this).val());
	  
	});
	
	form.action= '/SVGB-PIVI/relatorioFaturasEmitidasConsulta.do';
	if (validarGrupos($('#listaGruposSelecionadas option:selected[value!=-1]'))){	  
		if(comparaDatas(document.getElementById('dataInicial').value,document.getElementById('dataFinal').value)){
			if(validaSituacao(document.getElementById('situacao').value)){
				form.submit();
			}
		}
	}
}

function validarGrupos(pGrupos){
	var valor= $(pGrupos).length;
	if(valor > 0 ){
		return true;
	}else{
		if(validarApolices($('#listaApolicesSelecionadas option:selected[value!=-1]'))){
			return true;
		}else{
			return false;
		}
	}
}

function validarApolices(pApolices){
	var valor= $(pApolices).length;
	if(valor > 0 ){
		return true;
	}else{
		alert('Selecione um Grupo ou Apolice');
		return false;
	}
}

/**
 * Compara duas datas.
 * 
 */
function comparaDatas(dtInicial,dtFinal){	
	var alt = $.browser;
	
	if(dtInicial.length!=0){
		if(dtFinal.length!=0){	
			d = '01/'+dtInicial;	
			var pieces = d.split('/'); 
			pieces.reverse(); 
			var reversed = pieces.join('/');	
			dtInicial = reversed.split('/')
			
			if(dtInicial[1] > 12 || dtInicial[1] < 1){
				alert("O mês digitado é inválido");
				return false;
			}
			dtInicial = dtInicial[0]+dtInicial[1]+dtInicial[2];
			
				
			d = '01/'+dtFinal;	
			var pieces = d.split('/'); 
			pieces.reverse(); 
			var reversed = pieces.join('/');	
			dtFinal = reversed.split('/')
			if(dtFinal[1] > 12 || dtFinal[1] < 1){
				alert("O valor :'" + dtFinal[1] + "' é um mês inválido");
				return false;
			}
			dtFinal = dtFinal[0]+dtFinal[1]+dtFinal[2];	
			
			
			if(dtInicial <= dtFinal){
				return true;
			}else{
//				if($.browser.msie==true){  
//				    return true;
//				}else{
					alert('data inicio maior que data final');
					return false;
//				}
			}				
		}else{
			alert('Informe a data final');
			return false;
		}
	}else{
		if(dtFinal.length!=0){
			alert('Informe a data inicio');			
			return false;
		}
		alert('Período de Competência obrigatório!');
		return false;
	}
}

/**
 * validar Situacao. 
 */
function validaSituacao(pSituacao){
	var valor= pSituacao;
	
	if(pSituacao != -1 ){
		return true;
	}else{
		alert('Situação é um campo obrigatório');
		return false;
	}
}

function carregar(){
	$('#carregamento').show();
	$('#carregamento').html($('#carregamento').html());
	setTimeout("$('#carregamento').hide()", 3000);
}
