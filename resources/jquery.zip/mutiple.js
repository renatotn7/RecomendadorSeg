$.fn.loadMutiSelectID = function(){
	var table = this;
	//Bot�o Origem
	$($(table).find('a').eq(0)).click(
		function(){
			if($(table).find('select').eq(0).find('option[value=-1]:selected').length!=0){
				$(table).find('select').eq(1).append($(table).find('select').eq(0).find('option[value!=-1]'));
			}else{
				$(table).find('select').eq(1).append($(table).find('select').eq(0).find('option[value!=-1]:selected'));	
			}
			order(table);
		}
	);
	//Bot�o Destino
	$($(table).find('a').eq(1)).click(
		function(){
			if($(table).find('select').eq(1).find('option[value=-1]:selected').length!=0){
				$(table).find('select').eq(0).append($(table).find('select').eq(1).find('option[value!=-1]'));
			}else{
				$(table).find('select').eq(0).append($(table).find('select').eq(1).find('option[value!=-1]:selected'));
			}
			order(table);
		}
	);
};

function order(pTable){
	var op = $(pTable).find('select').eq(0).find('option');
	op.sort(function(a, b) {         
		return parseInt(a.value) > parseInt(b.value) ? 1 : -1;     
	}) 	
	$(pTable).find('select').eq(0).html(op);
	op = $(pTable).find('select').eq(1).find('option');
	op.sort(function(a, b) {         
		return parseInt(a.value) > parseInt(b.value) ? 1 : -1;     
	}) 	
	$(pTable).find('select').eq(1).html(op);
	
}




/**
 * 
	$('#NOME_ID').loadMutiSelect(
	 	{
	 		selectOrigem:	'NOME_ID',
	 		selectDestino:	'NOME_ID',
	 		botaoOrigem:	'NOME_ID',
	 		botaoDestino:	'NOME_ID'
	 	}
	 );
 *

$.fn.loadMutiSelectParam = function(param){
	$('#'+param.botaoOrigem).click(
		function(){
			$('#'+param.selectDestino).append($('#'+param.selectOrigem).find('option[value!=-1]:selected'));
			order(this);
		}
	);
	$('#'+param.botaoDestino).click(
		function(){								
			$('#'+param.selectOrigem).append($('#'+param.selectDestino).find('option[value!=-1]:selected'));
			order(this);
		}
	);
	
};
 */