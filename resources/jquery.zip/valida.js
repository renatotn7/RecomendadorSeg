var TOTAL_LIMITE_PROD = 100;
var MSG_LIMITE_PROD 	= 'Limite excedido de '+TOTAL_LIMITE_PROD+' produtos.';
var MSG_LIMITE_PROD_2 	= 'Para consulta de todos os produtos, favor retirar o filtro de produtos.';


//M�todo respons�vel na visualiza��o dos Popups de condi��o 
function abrirPopUp(pURL,pNomeArq,pCodProd,pTipoCond,pCdCob){
	pURL+='?pNomeArq='+$.trim(pNomeArq)+'&pTipoCond='+$.trim(pTipoCond)+'&pCdCob='+pCdCob+'&codProd='+$.trim(pCodProd); 
	var janela = geraPopUp(pURL,"Visualizar_Condi��o_Segurado"); 
	janela.focus();
}

//M�todo respons�vel pela visualiza��o do PDF 
function abrirPdf(pNomeArq,pCodProd,pTipoCond,pCdCob){
	var form = document.forms[0];
	//form.action = "/SVGB-PIVI/usuario/alterar/redirecionar-usuario-alteracao.do?codUsuario=" + codUsuario + "&codPerfil=" + codPerfil + "&nomeUsuario=" + nomeUsuario + "&acao=" + acao;
	//alert(pNomeArq);
	//alert(pCodProd);
	//alert(pTipoCond);
	//alert(pCdCob);
	form.action = "/SVGB-PIVI/abrirPdfCondSegurado.do?pNomeArq="+$.trim(pNomeArq)+"&pTipoCond="+$.trim(pTipoCond)+"&pCdCob="+pCdCob+"&codProd="+$.trim(pCodProd);
	form.submit();
}
 
//M�todo respons�vel pela visualiza��o do PDF 
function abrirPdfManual(pNomeArq,pCdCond,pTipoCond,pIdSegur){
	var form = document.forms[0];
	//form.action = "/SVGB-PIVI/usuario/alterar/redirecionar-usuario-alteracao.do?codUsuario=" + codUsuario + "&codPerfil=" + codPerfil + "&nomeUsuario=" + nomeUsuario + "&acao=" + acao;
	//alert(pNomeArq);
	//alert(pCodProd);
	//alert(pTipoCond);
	//alert(pCdCob);
	form.action = "/SVGB-PIVI/abrirPdfManualSegurado.do?pNomeArq="+$.trim(pNomeArq)+"&pTipoCond="+$.trim(pTipoCond)+"&pCdCond="+$.trim(pCdCond)+"&pIdSegur="+$.trim(pIdSegur);
	form.submit();
}

// Arquivo de valida��o

// Fun��o para Exibir o Help
function Exibe(){
	
	var div = document.getElementById("divHelpx").style;

	if(div.visibility=="hidden"){
		div.visibility="visible";
		$('#helpNavega').contents().find('#divHelpxFrame').show();
	}else{
		div.visibility="hidden";
		$('#helpNavega').contents().find('#divHelpxFrame').hide();
	}
	
}



/*
* Fun��o que s� aceita o input de caracteres num�ricos e alfa
*/
function validaString(str) {
	return str != null && str != ''  ;
}
 
function validaMes(mes){
	var bRet = true;

	if(null == mes || "" == mes){
		bRet = false;
	}
	
	if(mes > 12){
		bRet = false;
	}

	return bRet;
}


/*
* Fun��o que para redirecionar o Associar Grupo/SubGrupo
*/
function confRedirAssocGrupoApolice(codUsuario, codPerfil, nomeUsuario, acao){

	var form = document.forms[0];

	form.action = "/SVGB-PIVI/usuario/alterar/redirecionar-usuario-alteracao.do?codUsuario=" + codUsuario + "&codPerfil=" + codPerfil + "&nomeUsuario=" + nomeUsuario + "&acao=" + acao;
	form.submit();

}

/*
* Fun��o que s� aceita o input de caracteres num�ricos e alfa
*/
function validaCampoAlfaNum() {
   if ( ((event.keyCode>=33) && (event.keyCode<=46)) || 
     ((event.keyCode >=91) && (event.keyCode<=96)) || 
     ((event.keyCode >=58) && (event.keyCode<=63)) || 
     ((event.keyCode >=123)) ) {
        event.keyCode = 0;
   }
}

	function checkField(atual, proximo) {
	 	
	 	var campoAtual = document.getElementById(atual);
		var campoProximo = document.getElementById(proximo);
		var maxlength = campoAtual.getAttribute('maxlength');
		
		if(campoAtual.value.length == maxlength)  {
			campoProximo.focus();
		} else {
			campoAtual.focus();
		}
	}

/*
* Fun��o que s� aceita o input de caracteres num�ricos e "," e "."
*/
function validaCampoNumericoDecimal() {

    if (event.keyCode < 48 || event.keyCode > 57){
	  if (event.keyCode != 44 && event.keyCode != 46) {
   		event.keyCode = 0;
  	  }
 	}
}

/*
* Fun��o que s� aceita o input de caracteres num�ricos
*/
function validaCampoNumerico(event) {
  
	if(event.keyCode == 8 || event.keyCode == 46 || event.keyCode == 35 || event.keyCode == 9 || event.keyCode == 16 || event.keyCode == 17 || event.keyCode == 18 )
	{
		return true;
	}
    
    if (event.keyCode < 48 || event.keyCode > 57 && event.keyCode < 96 || event.keyCode > 105)
    {
  		return false;
 	}

}


//Fun��o que valida o CPF.

function check_cpf(){

	var numcpf = document.forms[0].cpf.value;

	x = 0;
	soma = 0;
	dig1 = 0;
	dig2 = 0;
	texto = "";
	numcpf1="";
	len = numcpf.length; x = len -1;

	if(numcpf == null || numcpf == ""){
		alert("Campo CPF n�o pode estar vazio.");
		return false;
	}

	for (var i=0; i <= len - 3; i++) {
		y = numcpf.substring(i,i+1);
		soma = soma + ( y * x);
		x = x - 1;
		texto = texto + y;
	}
	dig1 = 11 - (soma % 11);
	if (dig1 == 10) dig1=0 ;
	if (dig1 == 11) dig1=0 ;
	numcpf1 = numcpf.substring(0,len - 2) + dig1 ;
	x = 11; soma=0;
	for (var i=0; i <= len - 2; i++) {
		soma = soma + (numcpf1.substring(i,i+1) * x);
		x = x - 1;
	}
	dig2= 11 - (soma % 11);
	if (dig2 == 10) dig2=0;
	if (dig2 == 11) dig2=0;
	//alert ("Digito Verificador : " + dig1 + "" + dig2);
	if ((dig1 + "" + dig2) != numcpf.substring(len,len-2)) {
		alert ("Numero do CPF invalido.");
		return false;
	}

	javascript:document.forms[0].submit();
	return true;
}


/*
* Respons�vel pela valida��o de Alterar Senha.  A versao nova est em seguida
*/
//**************************************************************************
function validaAlterarSenhaAntiga(){

	var valorSenhaAtual = document.forms[0].senhaAtual.value;
	
	var valorNovaSenha = document.forms[0].novaSenha.value;
	var valorConfirmaSenha = document.forms[0].confirmaSenha.value;

	var primeiroSenhaAtual =  valorSenhaAtual.substr(0,1);
	var ultimoSenhaAtual	= valorSenhaAtual.substr(valorSenhaAtual.length-1,1);
	
	var primeiroNovaSenha =  valorNovaSenha.substr(0,1);
	var ultimoNovaSenha	= valorNovaSenha.substr(valorNovaSenha.length-1,1);
	

	if(valorSenhaAtual == "" || valorSenhaAtual == null){
		alert("Obrigat�rio digitar um valor para Senha Atual.");
		document.forms[0].senhaAtual.focus();
		return false;
	}
	
	if(valorSenhaAtual.length < 7 || valorSenhaAtual.length > 8){
		alert("Tamanho da senha tem que ser de 7 a 8 caracteres.");
		return false;
	}

	// verifica o primeiro e ultimo caracter para senha atual.	
	if(primeiroSenhaAtual.charCodeAt() < 65){
		alert("O 1� caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(primeiroSenhaAtual.charCodeAt() > 90 && primeiroSenhaAtual.charCodeAt() < 97){
		alert("O 1� caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(primeiroSenhaAtual.charCodeAt() > 122){
		alert("O 1� caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(ultimoSenhaAtual.charCodeAt() < 65){
		alert("O �ltimo caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(ultimoSenhaAtual.charCodeAt() > 90 && ultimoSenhaAtual.charCodeAt() < 97){
		alert("O �ltimo caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(ultimoSenhaAtual.charCodeAt() > 122){
		alert("O �ltimo caracter da senha dever� ser alfab�tico.");
		return false;
	}
	//************* fim ********************
	
	if(valorNovaSenha == "" || valorNovaSenha == null){
		alert("Obrigat�rio digitar um valor para Nova Senha.");
		document.forms[0].novaSenha.focus();
		return false;
	}
	
	if(valorNovaSenha.length < 7 || valorNovaSenha.length > 8){
		alert("Tamanho da senha tem que ser de 7 a 8 caracteres.");
		return false;
	}
	
	
	//Verifica o primeiro e �ltimo caracter da nova senha.
	if(primeiroNovaSenha.charCodeAt() < 65){
		alert("O 1� caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(primeiroNovaSenha.charCodeAt() > 90 && primeiroNovaSenha.charCodeAt() < 97){
		alert("O 1� caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(primeiroNovaSenha.charCodeAt() > 122){
		alert("O 1� caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(ultimoNovaSenha.charCodeAt() < 65){
		alert("O �ltimo caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(ultimoNovaSenha.charCodeAt() > 90 && ultimoNovaSenha.charCodeAt() < 97){
		alert("O �ltimo caracter da senha dever� ser alfab�tico.");
		return false;
	}
	
	if(ultimoNovaSenha.charCodeAt() > 122){
		alert("O �ltimo caracter da senha dever� ser alfab�tico.");
		return false;
	}
	//************ FIM ********************
	
	if(valorConfirmaSenha == "" || valorConfirmaSenha == null){
		alert("Obrigat�rio digitar um valor para Confirma Senha.");
		document.forms[0].confirmaSenha.focus();
		return false;
	}
	
	if(valorConfirmaSenha.length < 7 || valorConfirmaSenha.length > 8){
		alert("Tamanho da senha tem que ser de 7 a 8 caracteres.");
		return false;
	} 

	if(valorSenhaAtual == valorNovaSenha){
		alert("A nova senha n�o pode ser igual a senha atual.");
		return false;
	}
	
	if(valorNovaSenha != valorConfirmaSenha){
		alert("Nova senha n�o foi confirmada corretamente.");
		document.forms[0].confirmaSenha.focus();
		return false;
	}

	document.forms[0].submit();
	return true;	
}

/*
* Respons�vel pela valida��o de Alterar Senha.
*/
//**************************************************************************
function validaAlterarSenha(event){
	//$.blockUI({ message: '<h1> Alterando a senha...</h1>' });
	var valorSenhaAtual = document.forms[0].senhaAtual.value;
	var usuario = document.forms[0].cpf.value;
	var valorNovaSenha = document.forms[0].novaSenha.value;
	var valorConfirmaSenha = document.forms[0].confirmaSenha.value;

	var primeiroSenhaAtual =  valorSenhaAtual.substr(0,1);
	var ultimoSenhaAtual	= valorSenhaAtual.substr(valorSenhaAtual.length-1,1);
	
	var primeiroNovaSenha =  valorNovaSenha.substr(0,1);
	var ultimoNovaSenha	= valorNovaSenha.substr(valorNovaSenha.length-1,1);

	if(valorSenhaAtual == "" || valorSenhaAtual == null){
		alert("Obrigat�rio digitar um valor para Senha Atual.");
		document.forms[0].senhaAtual.focus();
		return false;
	}

	//************* fim ********************
	
	if(valorNovaSenha == "" || valorNovaSenha == null){
		alert("Obrigat�rio digitar um valor para Nova Senha.");
		document.forms[0].novaSenha.focus();
		return false;
	}
	
	if(valorNovaSenha.length < 8 || valorNovaSenha.length > 255){
		alert("Tamanho da senha tem que ser de 8 a 255 caracteres.");
		return false;
	}
	
	
	
	
	var i;
	var booSenha = 1;
	s = valorNovaSenha.toString();
	
	for (i = 0; i < s.length; i++ )
	{
		var c = s.charAt(i);
		if ( s.substr(i,1).charCodeAt() > 47 && s.substr(i,1).charCodeAt() < 58 )  
		{
			booSenha = 0; 
			break; 
		}
	}
	if (  booSenha == 1 ) {  
		alert("A senha n�o cont�m nenhum valor num�rico.");
		return false;
	}
	
	// 97 e 122 
	s = valorNovaSenha.toString();
	booSenha = 1;
	for (i = 0; i < s.length; i++ )
	{
		if ( s.substr(i,1).charCodeAt() > 96 && s.substr(i,1).charCodeAt() < 123 ) { 
			booSenha = 0; 
			break; 
		}
	}
	if (  booSenha == 1 ) {  
		alert("A senha n�o cont�m nenhuma letra min�scula.");
		return false;
	}
	
	//************ FIM ********************
	if(valorConfirmaSenha == "" || valorConfirmaSenha == null){
		alert("Obrigat�rio digitar um valor para Confirma Senha.");
		document.forms[0].confirmaSenha.focus();
		return false;
	}
	
	if(valorConfirmaSenha.length < 8 || valorConfirmaSenha.length > 255){
		alert("Tamanho da senha tem que ser de 8 a 255 caracteres.");
		return false;
	} 

	if(valorSenhaAtual == valorNovaSenha){
		alert("A nova senha n�o pode ser igual a senha atual.");
		return false;
	}
	
	
	if(valorNovaSenha != valorConfirmaSenha){
		alert("Nova senha n�o foi confirmada corretamente.");
		document.forms[0].confirmaSenha.focus();
		return false;
	}
	
	if(!alterarSenhaAjax(usuario,valorSenhaAtual,valorNovaSenha)){
		
		return false;
	}
	
	if(!autenticarAjax(usuario,valorNovaSenha)){
		document.forms[0].action='/SVGB-PIVI/login-view.do';
		document.forms[0].submit();
	}
	
	
	document.forms[0].action='/SVGB-PIVI/login-alterar-senha-view.do?usuario='+usuario+'&senha='+valorNovaSenha;
	document.forms[0].submit();
	return true;	
}

function teste(){
	$.blockUI({ message: '<h1> Alterando a senha...</h1>' });
}

/**
*Fun��o respons�vel por alterar a senha via ajax
*
**/
function alterarSenhaAjax(usuario,senhaAtual,novaSenha,event){
	//$(document).ajaxStart($.blockUI({ message: '<h1><img hspace="20" border="0" src="/SVGB-PIVI/images/pt_BR/aguarde.gif"><BR> Alterando a senha...</h1>' })).ajaxStop($.unblockUI);
	//$(document).ajaxStop($.unblockUI);
	//alert("chegou alterar senha");
	//$.blockUI({ message: '<h1> Alterando a senha...</h1>' });
            	//$("#alterandoSenha").css("display", "inline");
	$("#alterandoSenha").show();
				var url_func = '/SVGB-PIVI/alterarSenhaExpiradaEdirAjax.do?';
				url_func=url_func+='usuario='+usuario;
				url_func=url_func+='&senhaAtual='+senhaAtual;
				url_func=url_func+='&novaSenha='+novaSenha;
				var retorno = '';
				var retorno2 = '';
				var verifica=false;
				//alert($a('#j_username').val()+"teste jquert");
				
				
				try{
					//$.blockUI({ message: '<h1><img hspace="20" border="0" src="/SVGB-PIVI/images/pt_BR/aguarde.gif"><BR> Alterando a senha...</h1>' })
					//async: false, define que a requisi��o � sincrona aguarda o retorno do servidor para continuar
					
					$.ajax({
						type: "POST",
						dataType:"text",
						url: url_func,
						async: false,
						success:function(retorno){
						    
						retorno2=retorno;
						//$.unblockUI();
						}
				});
				
				
					
				
				var split = retorno2.split("-");

				var codRet = split[0];
				var mensagem = split[1];
				//$.unblockUI();
				//$("#alterandoSenha").css("display", "none");
				//alert(codRet);
				if(codRet!="0"){
					$("#alterandoSenha").hide();
					alert(mensagem);	
					return false;
				}
				
				}catch(e){
					$("#alterandoSenha").hide();
					//$.unblockUI();
				 alert("erro");
				 return false;
				}
				$("#alterandoSenha").hide();
			 
		return true;
	
	
}

/**
*Fun��o respons�vel por validar autentica��o de um usu�rio
*
**/
function autenticarAjax(usuario,novaSenha){
//	$(document).ajaxStart($.blockUI({ message: '<h1><img hspace="20" border="0" src="/SVGB-PIVI/images/pt_BR/aguarde.gif"><BR> Autenticando...</h1>' }));
//	$(document).ajaxStop($.unblockUI);
	//alert("chegou autenticar");
	//$.blockUI({ message: '<h1> Autenticando...</h1>' });
            	//$("#autenticando").css("display", "inline");
$("#autenticando").show();
				var url_func = '/SVGB-PIVI/autenticarUsuario.do?';
				url_func=url_func+='usuario='+usuario;
				url_func=url_func+='&senha='+novaSenha;
				var retorno = '';
				var retorno2 = '';
				var verifica=false;
				//alert($a('#j_username').val()+"teste jquert");
				
				
				try{
					
					//$.blockUI({ message: '<h1><img hspace="20" border="0" src="/SVGB-PIVI/images/pt_BR/aguarde.gif"><BR> Autenticando...</h1>' })
					//async: false, define que a requisi��o � sincrona aguarda o retorno do servidor para continuar
					$.ajax({
						type: "POST",
						dataType:"text",
						url: url_func,
						async: false,
						success:function(retorno){
						retorno2=retorno;
						//$.unblockUI();
						
						}
				});
				
					var split = retorno2.split("-");

					var codRet = split[0];
					var mensagem = split[1];
			//		$.unblockUI();
					//$("#alterandoSenha").css("display", "none");
					//alert(codRet);
					if(codRet!="0"){
						$("#autenticando").hide();
						alert(mensagem);	
						return false;
					}
				
					$("#autenticando").hide();
				
				
				}catch(e){
					//$.unblockUI();
				 alert("erro");
				 return false;
				}
				$("#autenticando").hide();
			 
		return true;
	
	
}

/**
*
* Caso a nova senha tenha o 1� caracter que n�o seja alfab�tico, 
* o sistema dever� informar que �O 1� caracter da senha dever� ser alfab�tico�.
* Vale tambem pro �ltimo caracter.
*
**/
function verificaUltimoPrimeiroCaracter(){
		
	var str = document.forms[0].senha.value;	
	var primeiro =  str.substr(0,1);
	var ultimo	= str.substr(str.length-1,1);
	var numcpf = document.forms[0].cpf.value;

	x = 0;
	soma = 0;
	dig1 = 0;
	dig2 = 0;
	texto = "";
	numcpf1="";
	len = numcpf.length; x = len -1;

	if(numcpf == null || numcpf == ""){
		alert("Campo CPF n�o pode estar vazio.");
		return false;
	}

	for (var i=0; i <= len - 3; i++) {
		y = numcpf.substring(i,i+1);
		soma = soma + ( y * x);
		x = x - 1;
		texto = texto + y;
	}
	dig1 = 11 - (soma % 11);
	if (dig1 == 10) dig1=0 ;
	if (dig1 == 11) dig1=0 ;
	numcpf1 = numcpf.substring(0,len - 2) + dig1 ;
	x = 11; soma=0;
	for (var i=0; i <= len - 2; i++) {
		soma = soma + (numcpf1.substring(i,i+1) * x);
		x = x - 1;
	}
	dig2= 11 - (soma % 11);
	if (dig2 == 10) dig2=0;
	if (dig2 == 11) dig2=0;
	//alert ("Digito Verificador : " + dig1 + "" + dig2);
	if ((dig1 + "" + dig2) != numcpf.substring(len,len-2)) {
	alert ("Numero do CPF invalido.");
	return false;
	}
	
	
	if(str == "" || str== null){
		alert("O campo senha n�o pode estar vazio.");
		return false;
	}
	
	if(str == "" || str== null){
		alert("O campo senha n�o pode estar vazio.");
		return false;
	}
	
	if(str.length < 7 || str.length > 8){
		alert("O tamanho da senha digitada est� incorreto, valor tem que ser de 7 a 8 caracteres.");
		return false;
	}
	
	
	if(primeiro.charCodeAt() < 65){
		alert("Senha inv�lida");
		return true;
	}
	
	if(primeiro.charCodeAt() > 90 && primeiro.charCodeAt() < 97){
		alert("Senha inv�lida");
		return false;
	}
	
	if(primeiro.charCodeAt() > 122){
		alert("Senha inv�lida");
		return false;
	}
	
	
	
	if(ultimo.charCodeAt() < 65){
		alert("Senha inv�lida");
		return true;
	}
	
	if(ultimo.charCodeAt() > 90 && ultimo.charCodeAt() < 97){
		alert("Senha inv�lida");
		return false;
	}
	
	if(ultimo.charCodeAt() > 122){
		alert("Senha inv�lida");
		return false;
	}
	
	document.forms[0].submit();
	return true;
	
}

//**************************************************************************


//  check for valid numeric strings	
function validaCampoNumericoString(strString)
{

   var strValidChars = "0123456789.-";
   var strChar;
   var blnResult = true;

   if (strString.length == 0) return false;

   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }

   return blnResult;
}

//  check for valid numeric strings	
function validaCampoNumericoString2(strString)
{

   var strValidChars = "0123456789";
   var strChar;
   var blnResult = true;

   if (strString.length == 0) return false;

   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }

   return blnResult;
}

/*
* Fun��o que s� aceita o input de caracteres Alfa
*/
function validaCampoAlfa() {
 if ( ((event.keyCode>=33) && (event.keyCode<=64)) || 
   ((event.keyCode >=91) && (event.keyCode<=96)) || 
   ((event.keyCode >=123) && (event.keyCode<=127)) || 
   (event.keyCode==168) ) {
   event.keyCode = 0;
 }
}

/*
* Fun��o para limpar os campos do formul�rio
*/ 
function resetForm(valor) {
var nomeForm = valor;
 eval("document."+nomeForm+".reset()");
}

 

/*
* Fun��o de valida��o de email email no input e no submit
* esta funcao pode ser substituida por uma regexp
*/
function validaEmail(form,campo) {
 var objeto = eval(form+"."+campo+".value");
 var objetoFocus = eval(form+"."+campo);
 var mensagem = "O e-mail informado parece n�o estar correto.";

 if(objeto == null || objeto == ""){
  alert("O campo email precisa ser preenchido.");
  return false;
 }

 if (objeto != "") {
  prim = objeto.indexOf("@")
  if(prim < 2) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("@",prim + 1) != -1) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf(".") < 1) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf(" ") != -1) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("zipmeil.com") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("hotmeil.com") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf(".@") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("@.") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf(".com.br.") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("/") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("[") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("]") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("(") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf(")") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
  if(objeto.indexOf("..") > 0) {
   alert (mensagem);
   objetoFocus.focus();
   objetoFocus.select();
   return false;
  }
 }
  return true;
}




/*
* Fun��o de submit p/ imagem ou texto
*/
function submitToUrl(form,url) {

 var nome = document.getElementById("nomeGrupo").value;

 if(nome == ""){
 alert("O campo nome precisa ser preenchido.");
 return false;
 }

 eval("document."+form+".action='"+url+"'");
 eval("document."+form+".submit()");
}

/*
* Fun��o de show/hide para qualquer objeto HTML (table, tr, td, span, etc..)
*/
function mostraImg(valor) {
var idTag = valor;
 if (document.getElementById(idTag).style.display == "none") {
  document.getElementById(idTag).style.display = "";
 } else {
  document.getElementById(idTag).style.display = "none";
 }
}

/**
* Verifica se o campo CPF est� preenchido e se o n�mero � valido
**/
function verificaCPF(numcpf){
//	var numcpf = document.forms[0].cpf.value;

	x = 0;
	soma = 0;
	dig1 = 0;
	dig2 = 0;
	texto = "";
	numcpf1="";
	len = numcpf.length; x = len -1;

	if(numcpf == null || numcpf == ""){
		alert("Campo CPF n�o pode estar vazio.");
		return false;
	}

	for (var i=0; i <= len - 3; i++) {
		y = numcpf.substring(i,i+1);
		soma = soma + ( y * x);
		x = x - 1;
		texto = texto + y;
	}
	dig1 = 11 - (soma % 11);
	if (dig1 == 10) dig1=0 ;
	if (dig1 == 11) dig1=0 ;
	numcpf1 = numcpf.substring(0,len - 2) + dig1 ;
	x = 11; soma=0;
	for (var i=0; i <= len - 2; i++) {
		soma = soma + (numcpf1.substring(i,i+1) * x);
		x = x - 1;
	}
	dig2= 11 - (soma % 11);
	if (dig2 == 10) dig2=0;
	if (dig2 == 11) dig2=0;
	//alert ("Digito Verificador : " + dig1 + "" + dig2);
	if ((dig1 + "" + dig2) != numcpf.substring(len,len-2)) {
	alert ("Numero do CPF invalido.");
	return false;
	}
	
	document.forms[0].submit();
	return true;
}

function selecionarTodosIncluirUsuario_onclick(divNome, chkSelecionarTodosNome){
		
	document.getElementById("hasChanges").value = 'true';
	var div = document.getElementById(divNome);
	var control = document.getElementById(chkSelecionarTodosNome);
	var value1 = 0;
	var value2 = 0;
	var check = false;
	var obrig  = false;

	for (var i = 0; i < div.childNodes.length; i++){
   			
	  	var child = div.childNodes[i];
	
   		if (child.tagName == "INPUT"){
   			
	   		if (child.type == "checkbox"){
    			child.checked = (control.checked) ? true : false;
   			 	value1 = child.value;
   			 	
   			 	check = child.checked;
   			 	obrig = false;
				if(child.disabled == true){
					child.checked = true;
	   			 	obrig = true;
				}
			}
			if (child.name.substring(0,6) == "obrig1" && check && obrig == false && child.value.substring(0,1) != "2"){
				value2 = child.value;
			}
			if (child.name.substring(0,6) == "obrig_" && check && obrig == false && child.value.substring(0,1) != "2"){
				child.value = "1_"+value1+"_"+value2;
			}
			if (child.name.substring(0,6) == "obrig_" && !check && child.value.substring(0,1) != "2"){
				child.value = "0_"+value1+"_"+value2;
			}
		}
  	}
}


function selecionarTodosDetalharFuncionalidade_onclick(divNome, chkSelecionarTodosNome){
		
	var div ;
	var control = document.getElementById(chkSelecionarTodosNome);
	var value1 = 0;
	var check = false;

	if(control == null){
		return;
	}
	var k = 0;

	while(( div = document.getElementById(divNome + '_'+ k)) != null){
		for (var i = 0; i < div.childNodes.length; i++){
	
		  	var child = div.childNodes[i];
	   				
	   		if (child.tagName == "INPUT"){
		   		if (child.type == "checkbox"){
	    			child.checked = (control.checked) ? true : false;
	   			 	value1 = child.value;
	   			 	check = child.checked;
				}
				if (child.name.substring(0,6) == "obrig_" && check){
					child.value = "0_"+value1;
				}
				if (child.name.substring(0,6) == "obrig_" && !check){
					child.value = "1_"+value1;
				}
			}
	  	}
	  	k++;
	 }
}


function check(name, obrig, value, name1){
	if(document.getElementById(name).checked == true){
		document.getElementById(obrig).value="1_"+document.getElementById(name).value+"_"+value;
	}
	else{
		document.getElementById(obrig).value="0_"+document.getElementById(name).value+"_"+value;
		document.getElementById(name1).checked = false;
	}
}

function validarSubmit(){

		var perfil = document.getElementById('perfil');
		var nome = document.getElementById('nome');
		var email = document.getElementById('email');
		var ddd = document.getElementById('ddd');
		var telefone = document.getElementById('telefone');
		var departamento = document.getElementById('departamento');
		var cargo = document.getElementById('cargo');
		var dia = document.getElementById('dia').value;
		var mes = document.getElementById('mes').value;
		var ano = document.getElementById('ano').value;
		var rg = document.getElementById('rg');
		var orgao = document.getElementById('orgao');
		var sexo = getRadioValue('sexo');
		var dataEmissaoDia = document.getElementById('dataEmissaoDia').value;
		var dataEmissaoMes = document.getElementById('dataEmissaoMes').value;
		var dataEmissaoAno = document.getElementById('dataEmissaoAno').value;
		var horarioAcessoHora1Inicio = document.getElementById('horarioAcessoHora1Inicio');
		var horarioAcessoMinuto1Inicio = document.getElementById('horarioAcessoMinuto1Inicio');
		var horarioAcessoHora2Fim = document.getElementById('horarioAcessoHora2Fim');
		var horarioAcessoMinuto2Fim = document.getElementById('horarioAcessoMinuto2Fim');
		var diasDeAcesso = document.getElementById('diasDeAcesso');
		var radioQTD = document.forms[0].diasDeAcesso.length;
		var radioColect = document.forms[0].diasDeAcesso;
		var radioValor = 0;
		var i;
		
		var horaInicio = parseInt(horarioAcessoHora1Inicio.value);
		var minutoInicio = parseInt(horarioAcessoMinuto1Inicio.value);
		var horaFim = parseInt(horarioAcessoHora2Fim.value);
		var minutoFim = parseInt(horarioAcessoMinuto2Fim.value);
		
		var somaInicio = (horaInicio*60) + minutoInicio;
		var somaFim = (horaFim*60) + minutoFim;
		
		var dataAtual = new Date();
		
		var dataNasc = new Date();
		
		var dataEmiss = new Date();
		
		
		if(perfil.value == null || perfil.value == '' || perfil.value == '0'){
			 alert("Campo perfil n�o pode estar vazio.");
			 return false;
		}
		 
	 	if(nome.value == null || nome.value == ''){
			 alert("Campo nome n�o pode estar vazio.");
			 return false;
		}
		
		if(email.value == null || email.value == ''){
			 alert("Campo e-mail n�o pode estar vazio.");
			 return false;
		}
	
		if (!verificaEmail(email.value)) {
			alert("Campo e-mail n�o est� no formato correto.");
			return false;
		}
		
		if(ddd.value.length == 1 ){
			 alert("Campo DDD n�o est� no formato correto.");
			 return false;
		}
		
		if(ddd.value == null || ddd.value == ''){
			 alert("Campo DDD n�o pode estar vazio.");
			 return false;
		}

		if(ddd.value == '00'){
			 alert("DDD inv�lido.");
			 return false;
		}
	
	 	if(telefone.value == null || telefone.value == '' || (telefone.value) == false ){
			 alert("Campo Telefone n�o pode estar vazio.");
			 return false;
		}

	 	if(validaCampoNumericoString2(telefone.value) == false){
			 alert("Campo Telefone deve ser num�rico.");
			 return false;
		}
		
		if(telefone.value.length < 5){
			 alert("Campo Telefone n�o est� no formato correto: XX XXXXXXXX");
			 return false;
		}
		
		if(departamento.value == null || departamento.value == ''){
			 alert("Campo Departamento n�o pode estar vazio.");
			 return false;
		}
		
		if(cargo.value == null || cargo.value == ''){
			 alert("Campo Cargo n�o pode estar vazio.");
			 return false;
		}
		
		if(dia.length == 1) {
			document.forms[0].dia.value = 0 + dia;
			dia = document.getElementById("dia").value;
		}
			
		if(mes.length == 1) {
			document.forms[0].mes.value = 0 + mes;
			mes = document.getElementById("mes").value;
		}
	
		if (!validaData(dia, mes, ano, 'Data de Nascimento')){
			return false;
		}	
		
		if(dia == null || dia == '' || mes == null || mes == '' || ano == null || ano == ''){
			 alert("Campo Data Nasc. n�o pode estar vazio.");
			 return false;
		}
		
		if (ano <= 1900){
			alert("Campo Data Nasc. deve ter ano maior que 1900.");
			return false;
		}	
		
		dataNasc.setFullYear(ano,mes-1,dia);
		
		
		if(dataNasc > dataAtual){
			alert("Campo Data Nasc. n�o pode ser maior que a data atual.");
			return false;
		}
		
		if (radioQTD == undefined){
			if(document.forms[0].radiobutton1.checked){
				radioValor = 1;
			}
	   	}
	   		 
	   	if(sexo == null || sexo == ''){
	   		alert("Campo 'Sexo' deve ser preenchido.");
	   		return false;
	   	
	   	}
		
		if(rg.value == null || rg.value == ''){
			 alert("Campo RG n�o pode estar vazio.");
			 return false;
		}
		
		if(orgao.value == null || orgao.value == ''){
			 alert("Campo �rg�o Emissor n�o pode estar vazio.");
			 return false;
		}	
		
		if(dataEmissaoDia.length == 1) {
			document.forms[0].dataEmissaoDia.value = 0 + dataEmissaoDia;
			dataEmissaoDia = document.getElementById("dataEmissaoDia").value;
		}
			
		if(dataEmissaoMes.length == 1) {
			document.forms[0].dataEmissaoMes.value = 0 + dataEmissaoMes;
			dataEmissaoMes = document.getElementById("dataEmissaoMes").value;
		}
		
		if (!validaData(dataEmissaoDia, dataEmissaoMes, dataEmissaoAno, 'Data de Emiss�o')){
			return false;
		}	
		
		if(dataEmissaoDia == null || dataEmissaoDia == '' || dataEmissaoMes == null || dataEmissaoMes == '' || dataEmissaoAno == null || dataEmissaoAno== ''){
			 alert("Campo Data Emiss�o n�o pode estar vazio.");
			 return false;
		}
		
		if (dataEmissaoAno <= 1900){
			alert("Campo Data Emiss�o deve ter ano maior que 1900.");
			return false;
		}	
		
		dataEmiss.setFullYear(dataEmissaoAno,dataEmissaoMes-1,dataEmissaoDia);
		
		
		if(dataEmiss > dataAtual){
			alert("Campo Data Emiss�o n�o pode ser maior que a data atual.");
			return false;
		}
		
		if(dataNasc >= dataEmiss){
			alert("Campo Data Emiss�o deve ser maior que a Data Nasc.");
			return false;
		}
		  		 
		for (i=0; i < radioQTD; i++){
	    	if (document.forms[0].diasDeAcesso[i].checked){
	       		radioValor = document.forms[0].diasDeAcesso[i].value;
	          	break;
	        }
	   	}
	 
		if(horarioAcessoHora1Inicio.value == null || horarioAcessoHora1Inicio == '' || horarioAcessoMinuto1Inicio.value == null || horarioAcessoMinuto1Inicio.value == '' || horarioAcessoHora2Fim.value == null || horarioAcessoHora2Fim.value == '' || horarioAcessoHora2Fim.value == null || horarioAcessoMinuto2Fim.value == ''){
			 alert("Campo Hor�rio de acesso n�o pode estar vazio.");
			 return false;
		}
		if(horarioAcessoHora1Inicio.value < 0 || horarioAcessoHora1Inicio.value > 24){
			alert("Campo Hora de Hor�rio de acesso de in�cio est� incorreto.");
			 return false;
		}
		if(horarioAcessoMinuto1Inicio.value < 0 || horarioAcessoMinuto1Inicio.value > 60){
			alert("Campo Minutos de Hor�rio de acesso de in�cio est� incorreto.");
			 return false;
		}
		if(horarioAcessoMinuto1Inicio.value > 0 && horarioAcessoHora1Inicio.value == 24){
			alert("Hor�rio de acesso de in�cio est� incorreto.");
			 return false;
		}
		if(horarioAcessoHora2Fim.value < 0 || horarioAcessoHora2Fim.value > 24){
			alert("Campo Hora de Hor�rio de acesso fim est� incorreto.");
			 return false;
		}
		if(horarioAcessoMinuto2Fim.value < 0 || horarioAcessoMinuto2Fim.value > 60){
			alert("Campo Minutos de Hor�rio de acesso fim est� incorreto.");
			 return false;
		}
		if(horarioAcessoMinuto2Fim.value > 0 && horarioAcessoHora2Fim.value == 24){
			alert("Hor�rio de acesso de fim est� incorreto.");
			 return false;
		}
		if(somaInicio > somaFim){
			alert("A hora inicial n�o pode ser maior do que a hora final.");
			return false;
		}
	
	   		
	   	if(radioValor == 0){
	   		alert("Campo Dias �teis n�o pode estar vazio.");
	   		return false;
	   	}
	
		var form = document.forms[0];
	
		preencherDadosFormatados();
	
		return true;
	}

function validarCheckboxSelecionado (){
	 var checkValor = 0;
	 var form = document.forms[0];
	 var x;
	 
	 for(x = 0 ; x < form.length; x++ ){
   		if( form.elements[x].type == 'checkbox'){
     		if( form.elements[x].checked ){
    			checkValor = 1;
    			break;
    		}
    		if(form.elements[x].disabled){
    		    checkValor = 1;
    			break;
    		} 
    	}
  	}
   	
   	if(checkValor == 0){
   		alert("Selecione uma funcionalidade.");
   		return false;
   	}
   	return true;
}

function validarCheckboxSelecionadoSubGrupo(){
	 var checkValor = 0;
	 var form = document.forms[0];
	 var x;
	 
	 for(x = 0 ; x < form.length; x++ ){
   		if( form.elements[x].type == 'checkbox'){
     		if( form.elements[x].checked ){
    			checkValor = 1;
    			break;
    		}
    		if(form.elements[x].disabled){
    		    checkValor = 1;
    			break;
    		} 
    	}
  	}
   	
   	if(checkValor == 0){
   		alert("Selecione um Subgrupo.");
   		return false;
   	}
   	return true;
}

function verificaEmail(email) {
	var pos, aux, pos2, dominio, carac, i
	email = email.toLowerCase(); 	
	
	if (email.indexOf("@",0) == -1 || email.length <= 8) {	
	 	return false;
	} 
	pos = email.indexOf("@",0) 
	aux = email.substring(pos+1)
	
	if (aux.indexOf("@",0) != -1) {
		return false;
	}
	
	if (aux.indexOf(".",0) < 2) {	
		return false;
	}	
	
	pos2 = aux.indexOf(".",0)
	dominio = aux.substr(0,pos2)
	
	
	if (dominio.length < 2) {	
		return false;
	}	
	
	carac = new Array("!","#","$","%","&","*","(",")","+","=","/","\\","|","?","'","\"","{","}","[","]","�","�",":",",",";","�","�","<",">")
	for(i=0; i<carac.length; i++) if (email.indexOf(carac[i],0) != -1) return false
	
	return true
}


function detalhamentoFuncionalidade(codFuncionalidade, nomeFuncionalidade, codUsuario, codPerfil, acaoUsuario){
		
	window.open('/SVGB-PIVI/usuario/detalhar-funcionalidade.do?codFuncionalidade=' + codFuncionalidade  + '&nomeFuncionalidade='+nomeFuncionalidade+'&acao=abrir&codUsuario=' + codUsuario + '&codPerfil=' + codPerfil + '&acaoUsuario=' + acaoUsuario + '&cmdForward=fwd-sucesso','','width=798,height=455,scrollbars=yes,status=yes');
}

function pesquisarAssociarGruposUsuario(){

	var argBusca = null;
	var paramBusca = null;
	var codUsuario = document.forms[0].codUsuario.value;
	var radioNome = document.forms[0].radiobutton.checked;
	var radioCodigo = document.forms[0].radiobutton1.checked;
	var nome = document.forms[0].nome.value;
	var codigo = document.forms[0].codigo.value;
	
	if(radioNome == false && radioCodigo == false){
		alert("� necess�rio escolher uma op��o.");
		return;
	}
	
	if(radioNome == true && nome == ""){
		alert("Para essa op��o � necess�rio preencher o nome.");
		return;
	}
	if(radioCodigo == true && codigo == ""){
		alert("Para essa op��o � necess�rio preencher o c�digo.");
		return;
	}

	if(document.forms[0].radiobutton.checked){
		argBusca = "nome";
		paramBusca = document.forms[0].nome.value;
	}
	else if(document.forms[0].radiobutton1.checked){
		argBusca = "codigo";
		paramBusca = document.forms[0].codigo.value;
	}
	window.open('/SVGB-PIVI/usuario/pesquisar-associar-grupos.do?argBusca=' + argBusca  + '&paramBusca=' + paramBusca + '&codUsuario=' + codUsuario +'&cmdForward=fwd-sucesso','','width=798,height=455,scrollbars=yes,status=yes');
}

function validaRadio(nomeRadio){
	
	if(nomeRadio == 'radiobutton'){
		document.forms[0].radiobutton1.checked = false;
		document.forms[0].codigo.value = "";
	}else if(nomeRadio == 'radiobutton1'){
		document.forms[0].radiobutton.checked = false;
		document.forms[0].nome.value = "";
	}
}


function getRadioValue(radioName) {
	var radioObj = document.forms[0].elements[radioName];

	if(!radioObj)
		return "";
	var radioLength = radioObj.length;

	if(radioLength == undefined)
	{	
		if(radioObj.checked)
		{
			return radioObj.value;
		}
		else
		{
			return "";
		}
	}

	for(var i = 0; i < radioLength; i++) {
		if(radioObj[i].checked) {
			return radioObj[i].value;
		}
	}
	return "";
}

function setCheckedValue(radioObj, newValue) {
	if(!radioObj){
		return;
	}
	var radioLength = radioObj.length;
	if(radioLength == undefined) {
		radioObj.checked = (radioObj.value == newValue.toString());
		return;
	}
	for(var i = 0; i < radioLength; i++) {
		radioObj[i].checked = false;
		if(radioObj[i].value == newValue.toString()) {
			radioObj[i].checked = true;
		}
	}
}


function getRadioValue2(radioName){
	var colRadio = document.getElementsByName(radioName);

	for (var i = 0; i < colRadio.length  ; i++){
		if (colRadio[i].checked){
			return colRadio[i].value;
		}
	}
	return null;
}


function getSelectedOptionFromSelect(selectId){
	var select = document.getElementById(selectId);

	for (var i = 0; i < select.options.length; i++){
		if (select.options[i].selected){
			return select.options[i];
		}
	}
	return null;
}

function validaData(dia, mes, ano, nomeCampo){
		// Valida Data.	

		if(!validaString(dia) || !validaString(mes)  || !validaString(ano) ){
			alert("O campo '" + nomeCampo + "' deve ser preenchido.");
			return false;
		}
		
		if(dia > 31 || dia < 1){
			alert("O campo dia foi informado incorretamente.");
			return false;
		} 
		
		if(mes > 12 || mes < 1){
			alert("O m�s do campo '" + nomeCampo + "' foi informado incorretamente.");
			return false;
		}
		
		if(ano.length != 4){
			alert("O ano do campo '" + nomeCampo + "' foi informado incorretamente.");
			return false;
		}
		
		if(ano%4!=0 && mes==2 && dia>28){
			alert("O m�s do campo '" + nomeCampo + "' possui apenas 28 dias.");
			return false;
		}
		
		if(ano%4==0 && mes==2 && dia>29){
			alert("O m�s do campo  '" + nomeCampo + "' possui apenas 29 dias.");
			return false;
		}
		
		if(mes == '04' || mes == '06' || mes == '09' || mes == '11'){
		
			if(dia > 30){
				alert("O m�s especificado no campo '" + nomeCampo + "' possui apenas 30 dias.");
				return false;
			}
		}
		return true;
}

    function validarCPF(cpf){
    
    	var numcpf = cpf

		x = 0;
		soma = 0;
		dig1 = 0;
		dig2 = 0;
		texto = "";
		numcpf1="";
		len = numcpf.length; x = len -1;
	
		if(numcpf == null || numcpf == ""){
			alert("Campo CPF n�o pode estar vazio.");
			return false;
		}

		for (var i=0; i <= len - 3; i++) {
			y = numcpf.substring(i,i+1);
			soma = soma + ( y * x);
			x = x - 1;
			texto = texto + y;
		}
		dig1 = 11 - (soma % 11);
		if (dig1 == 10) dig1=0 ;
		if (dig1 == 11) dig1=0 ;
		numcpf1 = numcpf.substring(0,len - 2) + dig1 ;
		x = 11; soma=0;
		for (var i=0; i <= len - 2; i++) {
			soma = soma + (numcpf1.substring(i,i+1) * x);
			x = x - 1;
		}
		dig2= 11 - (soma % 11);
		if (dig2 == 10) dig2=0;
		if (dig2 == 11) dig2=0;
		//alert ("Digito Verificador : " + dig1 + "" + dig2);
		if ((dig1 + "" + dig2) != numcpf.substring(len,len-2)) {
			alert ("Numero do CPF invalido.");
			return false;
		}
	
		
		return true;
    	
    }
    
        function formatar(src, mask) {
 		var i = src.value.length;
 	    var saida = mask.substring(0,1);
   		var texto = mask.substring(i)
 		if (texto.substring(0,1) != saida) {
       		src.value += texto.substring(0,1);
  		}
	}
	
		function formatarCpf(src) {
 		var i = src.length;
 		var dif = 11 - i;
 		var j = 0;
 		for(j = 0 ;j <  dif; j++) {
 			src = "0" + src;
 		} 
 		reCpf  = /(\d{3})(\d{3})(\d{3})(\d{2})$/;
		src = src.replace(reCpf, "$1.$2.$3-$4");
 		
  		return src;
  	}	

  	function addDWROptions(ele, data, optValue, optValue1, textValue, textDisplay, tamanho, tpRecuperacao){
  		//alert('passou');

	    var select = document.getElementById(ele);

		var text = new Object()

		text =  DWRUtil._getValueFrom(data[0], textDisplay) ;

		var texto = text.toString();

		var text = "";
		var value = "";		

		for (var i = 0; i < data.length; i++) {

			text =  DWRUtil._getValueFrom(data[i], textDisplay);

			if(text!="Selecione..."){

				text = DWRUtil._getValueFrom(data[i], textValue); 			

				texto = text.toString();

				while (texto.length < tamanho) texto = '0' +  texto;

				if(tpRecuperacao=='A'){//Recupera apolice					
					tpProd = DWRUtil._getValueFrom(data[i], 'tpProdEstp');
					tpProduto = tpProd.toString();

					if(tpProduto=='1' || tpProduto=='2'){
						texto = texto + ' | ' + DWRUtil._getValueFrom(data[i], 'nmProdutoEstp') ;
					}else{
						//alert('passou');
						texto = texto + ' | ' + DWRUtil._getValueFrom(data[i], 'nmSegEstp')  ;	
						texto= texto +' | '+ DWRUtil._getValueFrom(data[i], 'statusApolc');
					}
				}else{//Recupera subgrupo
					texto = texto + ' | ' + DWRUtil._getValueFrom(data[i], 'nomeSubf') ;				
				}
				
				value = DWRUtil._getValueFrom(data[i], optValue);

				value += '_';

				value += DWRUtil._getValueFrom(data[i], optValue1);

			}else{
				text =  DWRUtil._getValueFrom(data[i], textDisplay) ;

				value = DWRUtil._getValueFrom(data[i], optValue);		

			}

			var opt = new Option(texto, value);

			select.options[select.options.length] = opt;

		}
  	}
  	
  	function setRadioValue(radioName, valor) {
		var radioObj = document.forms[0].elements[radioName];
		var radioLength = radioObj.length;
	
		for(var i = 0; i < radioLength; i++) {
			if(radioObj[i].value == valor) {
				radioObj[i].checked = true;
			}
		}
	}

	function apoliceOnChange(fwd){
	
		var codFunc = GET("codFunc");
		var NomeFunc = GET("nomeFunc"); 
		       
		var grupoSelecionado = document.getElementById('grupoSelecionado').value;
		
		var apoliceSelecionada = document.getElementById('apoliceSelecionada').value;
		var subGrupo = document.getElementById('subGrupoSelecionado');
		
		if (subGrupo==null){
			subGrupo = {
				"value":-1
			}
		}
		if(fwd!=null){
			document.location.href = "/SVGB-PIVI/login/selecao-grupo-apolice.do?grupoSelecionado=" + grupoSelecionado + "&apoliceSelecionada=" + apoliceSelecionada + "&subGrupoSelecionado=" + subGrupo.value + '&cmdForward=' + fwd+'&codFunc='+codFunc+'&nomeFunc='+NomeFunc;
		}
		else{
			document.location.href = "/SVGB-PIVI/login/selecao-grupo-apolice.do?grupoSelecionado=" + grupoSelecionado + "&apoliceSelecionada=" + apoliceSelecionada + "&subGrupoSelecionado=" + subGrupo.value + '&cmdForward=fwd-menu-servico'+'&codFunc='+codFunc+'&nomeFunc='+NomeFunc;		
		}
	}

	function subGrupoOnChange(opt, fwd){        
		var grupoSelecionado = document.getElementById('grupoSelecionado').value;
		var apoliceSelecionada = document.getElementById('apoliceSelecionada').value;
		var subGrupo = document.getElementById('subGrupoSelecionado');
		subGrupo.value = opt.options[opt.selectedIndex].value ;

		if(fwd!=null){
			document.location.href = "/SVGB-PIVI/login/selecao-grupo-apolice.do?grupoSelecionado=" + grupoSelecionado + "&apoliceSelecionada=" + apoliceSelecionada + "&subGrupoSelecionado=" + opt.options[opt.selectedIndex].value + "&cmdForward=" + fwd;
		}
		else{
			document.location.href = "/SVGB-PIVI/login/selecao-grupo-apolice.do?grupoSelecionado=" + grupoSelecionado + "&apoliceSelecionada=" + apoliceSelecionada + "&subGrupoSelecionado=" + opt.options[opt.selectedIndex].value + "&cmdForward=fwd-menu-servico";		
		}
	}
	
	// fun��o que busca parametros da URL
	function GET(name){
	  var url   = window.location.search.replace("?", "");
	  var itens = url.split("&");
	
	  for(n in itens){
	    if( itens[n].match(name) ){
	      //return decodeURIComponent(itens[n].replace(name+"=", ""));
	      return itens[n].replace(name+"=", "");
	    }
	  }
	  return null;
	}


	function subGrupoOnChangeAdm(fwd){
		var subGrupo = document.getElementById('subGrupoSelecionado');
		var grupo = document.getElementById('grupoSelecionado');

		if(fwd!=null){
			document.location.href = "/SVGB-PIVI/login/selecao-grupo-apolice.do?subGrupoSelecionado=" + subGrupo.value  + "&cmdForward=" + fwd + "&grupoSelecionado=" + grupo.value;
		}
		else{
			document.location.href = "/SVGB-PIVI/login/selecao-grupo-apolice.do?subGrupoSelecionado=" + subGrupo.value  + "&cmdForward=fwd-menu-servico&grupoSelecionado=" + grupo.value;
		}
	}

 	/**	Fun��o respons�vel por validar a op��o selecionada Cia/Suc/Ap�lice/Sub-Grupo.
		As op��es v�lidas s�o:
		- CIA, Sucursal, Ap�lice e Sub-Grupo
		- Sucursal, Ap�lice e Sub-Grupo
		- Ap�lice e Sub-Grupo
		- Ap�lice
		
		Assim:
			2^3		2^2		2^1		2^0
			CIA		SUC		SGP		APO		Total
			 X		 X		 X		 X		= 15
			 		 X		 X		 X		= 7
			 		 		 X		 X		= 3
			 		 		 		 X		= 1
		_________________________________
			 8		 4		 2		 1
	*/

	function validarCiaSucApoliceSubgrupo(cia, suc, apolice, subGrupo) {
		var indice = 0;
		var campo = 0;
		
		// Se a op��o estiver preenchida, � somado valor segundo a tabela acima
		if (apolice != "") { campo = campo + Math.pow(2, 0); }
		if (suc != "") { campo = campo + Math.pow(2, 1); }
		if (cia != "") { campo = campo + Math.pow(2, 2); }

		// Se a soma n�o corresponder aos totais especificados acima (coluna total), a op��o n�o � v�lida
		if (campo != 1 && campo != 3 && campo != 7) {
			mensagem = "Pesquisa inv�lida. Favor preencher os campos de acordo com as op��es abaixo:"
				+ "\n\n"
				+ "- Ap�lice"
				+ "\n"
				+ "- Sucursal e Ap�lice"
				+ "\n"
				+ "- Cia, Sucursal e Ap�lice"
				+ "\n"
				+ "Obs: O Subgrupo � opcional em todas as consultas";
		
			alert(mensagem);
			return;
		} else {
			return true;
		}
	}
  	
	//M�todo que compara as datas
	function validaIntervalos(data_inicial, data_final){
	
		var msgData = "A data inicial deve ser menor que a data final.";
	
		//Verifica se a data inicial � maior que a data final
		if 	((data_inicial.value.length==10)&&(data_final.value.length==10)){
		    str_data_inicial = data_inicial.value;   
		    str_data_final   = data_final.value;   
		    dia_inicial      = data_inicial.value.substr(0,2);   
		    dia_final        = data_final.value.substr(0,2);   
		    mes_inicial      = data_inicial.value.substr(3,2);   
		    mes_final        = data_final.value.substr(3,2);   
		    ano_inicial      = data_inicial.value.substr(6,4);   
		    ano_final        = data_final.value.substr(6,4); 
			
		    if(ano_inicial > ano_final){   		        
		        
		        return false;
	
		    }else{
			
				if(ano_inicial == ano_final){
				
					if(mes_inicial > mes_final){
						
						return false;
	
					}else if(	(mes_inicial == mes_final)&&
								(dia_inicial > dia_final)){	

						return false;
					}
	
				}
				
			}
			
		    return true;
		    
		}
					
		return true;
	
	}
	
	//M�todo que compara as datas
	function validaIntervalosDesbloq(data_inicial, data_final){
	
		var msgData = "A data inicial deve ser menor que a data final.";
	
		//Verifica se a data inicial � maior que a data final
		if 	((data_inicial.value.length==10)&&(data_final.value.length==10)){
		    str_data_inicial = data_inicial.value;   
		    str_data_final   = data_final.value;   
		    dia_inicial      = data_inicial.value.substr(0,4);
		    dia_final        = data_final.value.substr(0,4);   
		    mes_inicial      = data_inicial.value.substr(5,7);   
		    mes_final        = data_final.value.substr(5,7);   
		    ano_inicial      = data_inicial.value.substr(8,10);   
		    ano_final        = data_final.value.substr(8,10); 
			
		    if(ano_inicial > ano_final){   		        
		        
		        return false;
	
		    }else{
			
				if(ano_inicial == ano_final){
				
					if(mes_inicial > mes_final){
						
						return false;
	
					}else if(	(mes_inicial == mes_final)&&
								(dia_inicial > dia_final)){	

						return false;
					}
	
				}
				
			}
			
		    return true;
		    
		}
					
		return true;
	
	}	
	
	//M�todo que gera Janela de PopUp
	function geraPopUp(pURL,pNomePopUp){
	
		var janelaPopUp = 	window.open	(	pURL,
											pNomePopUp,	
											"resizable=no,status=no,"+
											"scrollbars=yes"+
											",width=1000"+
											",height=500"+
											",left=90"+
											",top=60"
							);
	
		return 	janelaPopUp;
		
	}	
	
	//M�todo que executa retorna verdadeiro caso o evento da tecla seja um valor num�rico
	function somenteNumeros(event){	

		var tecla;
	
		if (window.event){ //IE
			tecla = event.keyCode; 
		}else if (event.which){ //FireFox
			tecla = event.which;
		}
		
		//teclas dos numemros(0 - 9) de 48 a 57
		//tecla==8 � para permitir o backspace funcionar para apagar
		
		if( (tecla >= 48 && tecla <= 57)||(tecla == 8 ) ){
			tecla  = null;
			return true;
		}else{			
			tecla  = null;
			return false;
		}
		
	}
	
	
	//	abre pagina com pdf
function executaAction(src){	
	var subGrupo= document.getElementById('subGrupoSelecionado'); // apolice com grupo
	var apolSubgrupo = document.getElementById('apoliceSelecionadaSemgrupo');  //apolice sem grupo
	
	if(subGrupo==null && apolSubgrupo==null){
		alert("� necess�rio Entrar em uma ap�lice");		
	}else{		 
//			exibeAguarde(true);
		window.open(src , "Teste", "width=800,height=600,scrollbars=YES");
// 			exibeAguarde(false);	
	}		
}

/**
*Fun��o respons�vel por validar CEP
*
**/
function validarCepAjax(cep){

//$("#autenticando").show();
				var url_func = '/SVGB-PIVI/validarCep.do?';
				url_func=url_func+='cep='+cep;
				var retorno = '';
				var retorno2 = '';
				var verifica=false;
			
				
				
				try{
					$.ajax({
						type: "POST",
						dataType:"text",
						url: url_func,
						async: false,
						success:function(retorno){
						retorno2=retorno;
						
						
						}
				});
				
					var split = retorno2.split("-");

					var codRet = split[0];
					var mensagem = split[1];

					if(codRet!="0"){
						//$("#autenticando").hide();
						//alert(mensagem);	
						return false;
					}
				
					//$("#autenticando").hide();
				
				
				}catch(e){
					
				 alert("Erro ao tentar validar CEP do respons�vel.");
				 return false;
				}

			 
		return true;
	
	
}

/**
*Fun��o respons�vel por recuper informa��o do CEP
*
**/
function recuperarCepAjax(cep){


				var url_func = '/SVGB-PIVI/recuperarCep.do?';
				url_func=url_func+='cep='+cep;
				var retorno = '';
				var retorno2 = '';
				var verifica	=	false;
			
				
				
				try{
					$.ajax({
						type: "POST",
						dataType:"text",
						url: url_func,
						async: false,
						success:function(retorno){
						retorno2=retorno;
						
						
						}
				});
					//alert(retorno2);
					var split = retorno2.split("-");
					var codRet = 		split[0];
					var mensagem = 		split[1];
				

					if(codRet!="0"){
						//alert(mensagem);	
						//$('#dadosResponsavelComunicadoNumero').val('');
					//	$('#dadosResponsavelComunicadoComplemento').val('');
						$('#dadosResponsavelBairro').val('');
						$('#dadosResponsavelMunicipio').val('');
						$('#dadosResponsavelComunicadoEndereco').val('');
						$('#dadosResponsavelComunicadoUf').val('');
						$('#dadosResponsavelBairro').prop('disabled', false);
						$('#dadosResponsavelMunicipio').prop('disabled', false);
						$('#dadosResponsavelComunicadoEndereco').prop('disabled', false);
						$('#dadosResponsavelComunicadoUf').prop('disabled', false);
						return false;
					}else{
						var bairro = 		split[2];
						var cepRetorno = 	split[3];
						var cidade = 		split[4];
						var complemento = 	split[5];
						var logradouro = 	split[6];
						var uf = 			split[7];
						$('#dadosResponsavelBairro').val(bairro);
						$('#dadosResponsavelMunicipio').val(cidade);
						$('#dadosResponsavelComunicadoEndereco').val(logradouro);
						$('#dadosResponsavelComunicadoUf').val(uf);
						//$('#dadosResponsavelComunicadoNumero').val('');
						//$('#dadosResponsavelComunicadoComplemento').val('');
						
						//$('#dadosResponsavelBairro').prop('disabled', true);
						//$('#dadosResponsavelMunicipio').prop('disabled', true);
						//$('#dadosResponsavelComunicadoEndereco').prop('disabled', true);
						//$('#dadosResponsavelComunicadoUf').prop('disabled', true);
					
					}
				
					//$("#autenticando").hide();
				
				
				}catch(e){
					
				 alert("Erro ao tentar validar CEP do respons�vel.");
				 return false;
				}

			 
		return true;
	
	
}



/**
*Fun��o respons�vel por recuper informa��o do CEP
*
**/
function carregarComboGrauParentescoAjax(natureza){


				var url_func = '/SVGB-PIVI/carregarComboGrauParentesco.do?';
				url_func=url_func+='natureza='+natureza;
				var retorno2 = '';

			
				if(natureza=='Selecione...'){
					$('#dadosDoSinistradoRelacionamento').empty();
					$('#dadosDoSinistradoRelacionamento').append(new Option('Selecione...', 'Selecione...'));
					return false;
					
				}
				
				try{
					$.ajax({
						type: "POST",
						dataType:"text",
						url: url_func,
						async: false,
						success:function(retorno){
						retorno2=retorno;
						
						
						}
				});
					//alert(retorno2);
					var split = retorno2.split("-");
					var codRet = 		split[0];
					var mensagem = 		split[1];
					var combos = 		split[2];
				

					if(codRet!="0"){
					//alert(mensagem);	
					//$('#dadosResponsavelComunicadoNumero').val('');
					//	$('#dadosResponsavelComunicadoComplemento').val('');
					//	$('#dadosResponsavelBairro').val('');
					//	$('#dadosResponsavelMunicipio').val('');
					//	$('#dadosResponsavelComunicadoEndereco').val('');
					//	$('#dadosResponsavelComunicadoUf').val('');
					//	$('#dadosResponsavelBairro').prop('disabled', false);
					//	$('#dadosResponsavelMunicipio').prop('disabled', false);
					//	$('#dadosResponsavelComunicadoEndereco').prop('disabled', false);
					//	$('#dadosResponsavelComunicadoUf').prop('disabled', false);
						return false;
					}else{
						var splitCombos = 	combos.split("*");
						$('#dadosDoSinistradoRelacionamento').empty();
						if(	splitCombos.length>1){
							$('#dadosDoSinistradoRelacionamento').append(new Option('Selecione...', 'Selecione...'));
						}
						for( var i=0 ; i < (splitCombos.length) ; i++){
							combo = splitCombos[i];
							splitCombo = combo.split("|");
							var codigo   =	splitCombo[0];
							var descricao=	splitCombo[1];

							if(descricao!=''){
								$('#dadosDoSinistradoRelacionamento').append(new Option(descricao, descricao));
							}
							
						}
			
						$("#dadosDoSinistradoRelacionamento").prop("disabled", false);
					}
				
				
				
				}catch(e){
					
				 alert("Erro ao tentar carregar  grau de parentesco.");
				 return false;
				}

				
		return true;
	
	
}



	
