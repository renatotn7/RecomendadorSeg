/* Scripts a serem executados ao inicializar as p�ginas */
$(document).ready(function(){
	insereMascaraDataDdMmYyyy();

	/*
	 * 2014-002724-01 - Novo componente de Calend�rio
	 * Foi solicitado que a chamada do antigo calend�rio deveria ser adaptada
	 * para chamar automaticamente o novo componente.
	 * 
	 * A fun��o abaixo desfaz a chamada do antigo componente e carrega de
	 * maneira din�mica o novo componente. Para maiores detalhes, vide c�digo
	 * da fun��o.
	 */
	// 15/10/2014 - Adaptador desativado por solicita��o
	//carregarCssJsCalendario();
});

//-----------------------------------------------------------------------
//ROTINAS GEN�RICAS
//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
// Validacao de Data
function verificaData(Data)
 {
  // O parametro Data dever� estar no formato dd/mm/yyyy
  if (Data.length != 10) return false;
	
  var dma = -1;
  var data = Array(3);
  var ch = Data.charAt(0); 
  for(i=0; i < Data.length && (( ch >= '0' && ch <= '9' ) || ( ch == '/' && i != 0 ) ); ){
   data[++dma] = '';
   if(ch!='/' && i != 0) return false;
   if(i != 0 ) ch = Data.charAt(++i);
   if(ch=='0') ch = Data.charAt(++i);
   while( ch >= '0' && ch <= '9' ){
    data[dma] += ch;
    ch = Data.charAt(++i);
   } 
  }
  if(ch!='') return false;
  if(data[0] == '' || isNaN(data[0]) || parseInt(data[0]) < 1) return false;
  if(data[1] == '' || isNaN(data[1]) || parseInt(data[1]) < 1 || parseInt(data[1]) > 12) return false;
  if(data[2] == '' || isNaN(data[2]) || ((parseInt(data[2]) < 0 || parseInt(data[2]) > 99 ) && (parseInt(data[2]) < 1900 || parseInt(data[2]) > 9999))) return false;
  if(data[2] < 50) data[2] = parseInt(data[2]) + 2000;
  else if(data[2] < 100) data[2] = parseInt(data[2]) + 1900;
  switch(parseInt(data[1])){
   case 2: { if(((parseInt(data[2])%4!=0 || (parseInt(data[2])%100==0 && parseInt(data[2])%400!=0)) && parseInt(data[0]) > 28) || parseInt(data[0]) > 29 ) return false; break; }
   case 4: case 6: case 9: case 11: { if(parseInt(data[0]) > 30) return false; break;}
   default: { if(parseInt(data[0]) > 31) return false;}
  }
  return true; 
 }

// Muda Formato da Data
function mudaFormatoData(Data, Formato)
{
	// O parametro Data dever� estar no formato dd/mm/yyyy
	var ano = Data.substring(6,10);
	var mes = Data.substring(3,5);
	var dia = Data.substring(0,2);

	var dataTemp ;
	if (Formato == "yyyymmdd")
	{
		dataTemp = ano + mes + dia;	
	}
	if (Formato == "yyyy-mm-dd")
	{
		dataTemp = ano + '-' + mes + '-' + dia;	
	}
	if (Formato == "mm/dd/yyyy")
	{
		dataTemp = mes + '/' + dia + '/' + ano;	
	}
	if (Formato == "mmddyyyy")
	{
		dataTemp = mes + dia + ano;	
	}
	if (Formato == "ddmmyyyy")
	{
		dataTemp = dia + mes + ano;	
	}

	return dataTemp;
}

function DiffDate(Data1, Data2)
{
  var MINUTE = 60 * 1000
  var HOUR = MINUTE * 60
  var DAY = HOUR * 24
  var WEEK = DAY * 7

  Data1 = mudaFormatoData(Data1,'mm/dd/yyyy')
  Data2 = mudaFormatoData(Data2,'mm/dd/yyyy')
  
  var dData1 = new Date(Data1)
  var dData2 = new Date(Data2)
  return ((dData2 - dData1) / DAY)
}

function addZero(vNumber){ 
	return ((vNumber < 10) ? "0" : "") + vNumber 
} 

function formatDate(vDate, vFormat){ 
    var vDay              = addZero(vDate.getDate()); 
    var vMonth            = addZero(vDate.getMonth()+1); 
    var vYearLong         = addZero(vDate.getFullYear()); 
    var vYearShort        = addZero(vDate.getFullYear().toString().substring(3,4)); 
    var vYear             = (vFormat.indexOf("yyyy")>-1?vYearLong:vYearShort) 
    var vHour             = addZero(vDate.getHours()); 
    var vMinute           = addZero(vDate.getMinutes()); 
    var vSecond           = addZero(vDate.getSeconds()); 
    var vDateString       = vFormat.replace(/dd/g, vDay).replace(/MM/g, vMonth).replace(/y{1,4}/g, vYear) 
    vDateString           = vDateString.replace(/hh/g, vHour).replace(/mm/g, vMinute).replace(/ss/g, vSecond) 
    return vDateString 
}

//Abre uma p�gina popup
function abrirPopup(url, largura, altura, posicaoX, posicaoY, barraLateral) {
    window.open(url,"","width=" + largura + ",height=" + altura + ",screenX=" + posicaoX + ",screenY=" + posicaoY + ",scrollbars=" + barraLateral + ",status=no,dependent=yes,resizable=no");
}


/* Data: 10.02.2010
 * Fun��o: Permitir a digita��o apenas de caracteres num�ricos.  
 */
function mascaraInteiro(event){	    	 
	var keyCode = event.keyCode?event.keyCode:event.which?event.which:event.charCode;	    	
	if (keyCode < 48 || keyCode > 57){
	    event.returnValue = false;
	    return false;
	}
	return true;
}   

/* Data: 10.02.2010
 *  Fun��o: Limpar campos numerico cujos caracteres colados (preenchidos via CTRL + V) sejam n�o num�ricos.
 */
function confirmarIsNumber(campo, nmCampo, isInteiro){   
    var strCampo = campo.value;
	           
    for (i = 0; i < strCampo.length; i++) {     
        if(isInteiro == true){
        	if (!(strCampo.charAt(i) == '0' || strCampo.charAt(i) == '1' || strCampo.charAt(i) == '2' || strCampo.charAt(i) == '3' || strCampo.charAt(i) == '4' || strCampo.charAt(i) == '5' || strCampo.charAt(i) == '6' || strCampo.charAt(i) == '7' || strCampo.charAt(i) == '8' || strCampo.charAt(i) == '9')) {                     
	            document.getElementById(nmCampo).value = '';
	            i = strCampo.length;
				document.getElementById(nmCampo).focus();
				return true;
	        }
        } else{
        	if (!(strCampo.charAt(i) == '0' || strCampo.charAt(i) == '1' || strCampo.charAt(i) == '2' || strCampo.charAt(i) == '3' || strCampo.charAt(i) == '4' || strCampo.charAt(i) == '5' || strCampo.charAt(i) == '6' || strCampo.charAt(i) == '7' || strCampo.charAt(i) == '8' || strCampo.charAt(i) == '9' || strCampo.charAt(i) == '.' || strCampo.charAt(i) == ',')) {                     
	            document.getElementById(nmCampo).value = '';
	            i = strCampo.length;
				document.getElementById(nmCampo).focus();
				return true;
	        }
        }	        	             
    }
    return false;
}


/* Data: 19.02.2010
 * Fun��o: Permitir que os campos Dia, M�s e Ano de uma data sejam preenchidos como se fossem um �nico campo.
 */
function formatarData(field, event) {        	 
	var keyCode = event.keyCode?event.keyCode:event.which?event.which:event.charCode;
	
	if(mascaraInteiro(event)) {			
		
		if(field.value.length == (field.maxLength - 1)) {		    
			for (i = 0; i < field.form.elements.length; i++)
				if (field == field.form.elements[i])
					break;
			i = (i+1) % field.form.elements.length;			
			
			
				switch(keyCode){					
					case 48:
						field.value = field.value + "0";
						break;
					case 49:
						field.value = field.value + "1";					
						break;
					case 50:
						field.value = field.value + "2";
						break;
					case 51:					   
						field.value = field.value + "3";
						break;
					case 52:
						field.value = field.value + "4";
						break;
					case 53:
						field.value = field.value + "5";
						break;
					case 54:
						field.value = field.value + "6";
						break;
					case 55:
						field.value = field.value + "7";
						break;
					case 56: 
						field.value = field.value + "8";
						break;
					case 57:
						field.value = field.value + "9";
						break;
				}	    
			//}			
			event.returnValue = false;
			field.form.elements[i].focus();
		} 					
		return true;
	
	} else if(keyCode == 9 && field.value.length!= 0) {		
		completarData(field, event);			
		return false;				
	
	} else if(keyCode == 46 || keyCode == 8 || keyCode == 27 || (keyCode > 44 && keyCode < 51)) {	    		
		if(keyCode == 8 && field.value == '') {			
			for (i = 0; i < field.form.elements.length; i++)
				if (field == field.form.elements[i])
					break;
			i = (i - 1) % field.form.elements.length;
			field.form.elements[i].select();
		}
		return true;
	} else {
		return false;
	}
}

/* Data: 10.02.2010
 * Fun��o: Completar os campos Dia, M�s ou Ano de uma data. 
 */
function completarData(campo, event) {	
	if(campo.value.length < campo.maxLength) {
		if(campo.maxLength == 2 && campo.value!='0' && campo.value!='' && campo.value.length==1){
			campo.value = '0' + campo.value;
		} else if(campo.maxLength == 4 && campo.value!='0' && campo.value!='' && campo.value.length==2) {		
			campo.value = '20' + campo.value;
		}
	}
}

/* Data: 08.03.2010
 * Fun��o: Montar a data de exibi��o com os campos dia, mes e ano.
 */
function iniciarCalendario(objData,div,tam) {
	if(document.getElementById('popFrame') != null ) {
		document.getElementById('popFrame').style.display="block";
	}
	
	var dataExibicao = document.getElementById(objData).value;
	exibirCalendario(objData,div,tam,dataExibicao);
}

/* Data: 28/02/2014
 * Fun��o: Converter todas as datas para dois d�gitos
 * Ex.: "05/02/2014" ao inv�s de "5/2/2014"
 * */
function diaMesComDoisDigitos(numero) {
	var resultado = numero.toString();
	if (resultado.length == 1) {
		resultado = "0" + resultado;
	}
	return resultado;
}

/* Data: 05.03.2010
 * Fun��o: Construir o calend�rio a ser exibido no clique da imagem calend�rio.
 */
function exibirCalendario(objData,div,tam,vlrData) {
    var dia = "", mes = "", ano = "", c = 1, caracterData = "", dataSelecionada, div2;
    
    //Se uma data tiver sido informada, o calendario deve abrir com o m�s e ano da data selecionda.
    if (vlrData) {               
        for(s=0;s<parseInt(vlrData.length);s++) {
            caracterData = vlrData.substr(s,1);
            if(caracterData == "/") {
                c++; 
                s++; 
                caracterData = vlrData.substr(s,1);
            }
            if(c==1) dia += caracterData;
            if(c==2) mes += caracterData;
            if(c==3) ano += caracterData;
        }
        vlrData = mes + "/" + dia + "/" + ano;
    }
    
    if(!vlrData) {
		dataSelecionada = new Date();
	} else {
		dataSelecionada = new Date(vlrData);
	}	      
    ano = dataSelecionada.getFullYear();
    mes = dataSelecionada.getMonth();
    dia = dataSelecionada.toString ().substr (8,2);  
      
    mesesAno = new Array("Janeiro", "Fevereiro", "Mar&ccedil;o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro");
    qtdDiasFevereiro = (!(ano % 4) ? 29 : 28);
    qtdDiasMes = new Array(31, qtdDiasFevereiro, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);

    if((mes - 1) == -1) {
		mesAnterior = 11; 
		anoAnterior = ano - 1;
	} else {
		mesAnterior = mes - 1; 
		anoAnterior = ano;
	}
    if ((mes + 1) == 12) {
		month_next  = 0;  
		year_next  = ano + 1
	} else {
		month_next = mes + 1; 
		year_next = ano;
	}
    
    txt  = "<table class='pop_calendario_box_interno' cellspacing='0' cellpadding='5' border='0' width='"+tam+"' height='"+tam*1.1 +"'>";
    txt += "  <tr>";
    txt += "    <td colspan='7' align='center'>";
    txt += "      <table border='0' cellpadding='0' width='100%'>";
    txt += "        <tr class='pop_calendario_nav_mes'>";
    txt += "          <td width=2% align=center>&nbsp;</td>";
    txt += "          <td width=10% align=left>";
    txt += "            <a href=javascript:exibirCalendario('"+objData+"','"+div+"','"+tam+"','"+( "01/" + (mesAnterior+1).toString() + "/" + anoAnterior.toString())+"') class='pop_calendario_nav_mes_item' title='M&ecirc;s Anterior'><</a>";
    txt += "          </td>";
    txt += "          <td width=75% align=center>";
    txt += "            <b>" + ano.toString() + "&nbsp;&nbsp;" + mesesAno[mes] + "</b>";
    txt += "          </td>";
    txt += "          <td width=10% align=right>";
    txt += "            <a href=javascript:exibirCalendario('"+objData+"','"+div+"','"+tam+"','"+( "01/" + (month_next+1).toString()  + "/" + year_next.toString())+"') class='pop_calendario_nav_mes_item' title='Pr&oacute;ximo M&ecirc;s'>></a>";
    txt += "          </td>";
    txt += "          <td width=3% align=right class='pop_calendario_nav_mes_fecha'>";
    txt += "            <a href=javascript:fecharCalendario('"+div+"') title='Fechar Calend&aacute;rio'><b>X</b></a>";
    txt += "          </td>";
    txt += "        </tr>";
    txt += "      </table>";
    txt += "    </td>";
    txt += "  </tr>";
    txt += "  <tr class='pop_calendario_rotulo_semana'>";
    txt += "    <td width='14%' class='dia' align=center>Dom</td>";
    txt += "    <td width='14%' class='dia' align=center>Seg</td>";
    txt += "    <td width='14%' class='dia' align=center>Ter</td>";
    txt += "    <td width='14%' class='dia' align=center>Qua</td>";
    txt += "    <td width='14%' class='dia' align=center>Qui</td>";
    txt += "    <td width='14%' class='dia' align=center>Sex</td>";
    txt += "    <td width='14%' class='dia' align=center>Sab</td>";
    txt += "  </tr>";
    dataAtualFormat = new Date((mes+1).toString() +"/01/"+ano.toString());
    diainicio = dataAtualFormat.getDay() + 1;
    semana = d = 1
    inicio = false;

    for(n=1;n<= 42;n++) {
        if(semana == 1) txt += "<tr align='center' class='pop_calendario_dias_mes'>";
        if(semana==diainicio) inicio = true;
        if(d > qtdDiasMes[mes]) inicio=false;
        if(inicio) {
            dat = new Date((mes+1).toString() + "/" + d + "/" + ano.toString());
            diaSelect   = dat.toString().substr(0,10);
            diaAtual  = dataSelecionada.toString().substr(0,10);
            anoSelect  = dat.getFullYear();
            anoAtual = dataSelecionada.getFullYear();
            estiloCelData = ((diaSelect == diaAtual) && (anoSelect == anoAtual) ? " bgcolor='#d3d3d3' " : "" );
            txt += "<td " + estiloCelData + " align=center><a href=javascript:registrarData('"+objData+"','"+  diaMesComDoisDigitos(d) + "/" + diaMesComDoisDigitos(mes+1) + "/" + ano.toString() +"','" + div +"') class='data'>"+ d.toString() + "</a></td>";
            d++;
        } else { 
            txt += "<td class='data' align=center>&nbsp;</td>"
        }        
        semana++;
        if(semana == 8) { 
            semana = 1; txt += "</tr>";
        } 
    }
    txt += "</table>";    
    div2 = document.getElementById(div);
    div2.innerHTML = txt; 
	
	var offset = $("#" + objData).offset()
	$("#" + div ).css('left', offset.left-113);
	$("#" + div ).css('top' , offset.top);
}


/* Data: 05.03.2010
 * Fun��o: Fechar o calend�rio.
 */
function fecharCalendario(div) { 
	if( document.getElementById('popFrame') != null ) {
		document.getElementById('popFrame').style.display="none";
	}
	
	div2 = document.getElementById(div);
	div2.innerHTML = '';
}


/* Data: 05.03.2010
 * Fun��o: Fechar o calend�rio e setar a data no campo de data associado.
 */
function registrarData(objData,data,div) {       
    var obj2, dtSplit, obj3, obj4;
    fecharCalendario(div);
    dtSplit = data.split("/");   
    
    obj2 = document.getElementById(objData);
    obj2.value = data;
}

/* Fun��o: Divide a data entre os campos dia, m�s e ano
 */
function carregarData(dataHidden, nomeDia, nomeMes, nomeAno) {
	var dtHidden = document.getElementById(dataHidden);
	var dia = document.getElementById(nomeDia); 
	var mes = document.getElementById(nomeMes); 
	var ano = document.getElementById(nomeAno);
	
	if( dtHidden == null )
		return;
	
	if(dtHidden.value!='' && dtHidden.value.length==10)	{
		dia.value = dtHidden.value.substring(0,2);
		mes.value = dtHidden.value.substring(3,5);
		ano.value = dtHidden.value.substring(6,11);
	}else
		if(dtHidden.value!='' && dtHidden.value.length>10)	{
			dia.value = dtHidden.value.substring(8,11);
			mes.value = dtHidden.value.substring(5,7);
			ano.value = dtHidden.value.substring(0,4);
		}
}

/* Fun��o: Carrega o dia, m�s e ano para o Hidden no formato dd/mm/aaaa
 */
function carregarDataHidden(dataHidden, nomeDia, nomeMes, nomeAno) {
	var dtHidden = document.getElementById(dataHidden);
	var dia = document.getElementById(nomeDia); 
	var mes = document.getElementById(nomeMes); 
	var ano = document.getElementById(nomeAno); 
 
	if(dia.value.length==1){
		document.getElementById(nomeDia).value='0'+dia.value;
		alert(document.getElementById(nomeDia).value);
	}
	if(mes.value.length==1){
		document.getElementById(nomeMes).value='0'+mes.value;
	}
	
	if(dia.value=='' && mes.value=='' && ano.value==''){
		dtHidden.value=''
	} else {
		dtHidden.value = dia.value + "/" + mes.value + "/" + ano.value;
	}
}

/* Data: 22/07/2014
 * Fun��o: Adiciona m�scara de data dd/mm/yyyy aos campos com a classe
 * css padr�o, caso a biblioteca jquery.maskedinput esteja presente. */
function insereMascaraDataDdMmYyyy(){
	if (typeof($(".mask_ddmmyyyy").mask) === "function") { 
		$(".mask_ddmmyyyy").mask("99/99/9999");
	}
}

/*
 * 09/10/2014
 * Se��o de carregamento din�mico de Scripts e CSS�s
 * Utilizado no componente de calend�rio bootstrap-datepicker.js
 */

function sucessoLoadExterno() {
	// console.log('sucessoLoadExterno');
}

function falhaLoadExterno() {
	// console.log('falhaLoadExterno');
}

/*
 * 2014-002724-01 - Novo componente de Calend�rio
 * Foi solicitado que a chamada do antigo calend�rio deveria ser adaptada
 * para chamar automaticamente o novo componente.
 * 
 * A fun��o abaixo desfaz a chamada do antigo componente e carrega de
 * maneira din�mica o novo componente. Para maiores detalhes, vide c�digo
 * da fun��o.
 */
function carregarCssJsCalendario() {
	$('.blocoInputCalendario_template').addClass('box_bsCalendario');
	$('.blocoInputCalendario').addClass('box_bsCalendario');
	$('.dentroBlocoInput').addClass('botao_bsCalendario');
	$('.dentroBlocoInput').removeAttr('onclick');
	$('.inputs.calendario.input_de_filtro').addClass('bsCalendario');

	var enderecoPadroesWeb, nomeArqJs, nomeArqCss;
	/*
	 * Obtendo o endere�o do padr�es web no ambiente atual a partir
	 * a partir do endere�o de chamada do pr�prio util.js 
	 */
	enderecoPadroesWeb = $('script[src*="util.js"]').attr('src').replace('js/util.js','');
	nomeArqJs = enderecoPadroesWeb + 'js/bootstrap-datepicker.js';
	nomeArqCss = enderecoPadroesWeb + 'css/bootstrap-datepicker.css';

	ScriptLoader.load([
		{ file:nomeArqJs  , type:"js"},
		{ file:nomeArqCss , type:"css"}], 
		sucessoLoadExterno, 
		falhaLoadExterno);
}

/*
	ScriptLoader v1.0

	A utility to load javascript and css files dynamically. Call success or failure functions at the end.

	Author: Asim Ishaq
	Web: asimishaq.com

	License: GPL v2 or later
*/


var ScriptLoader = {
	/**
	@param 	scripts: array of css and js files
			[{file:"",type:"css"},{file:"",type:"js"},..]
	@param 	success: callback function if all scripts are loaded successfully.
	@param 	failure: callback function if any script fails loading or timeouts.
	*/
	load: function (scripts, success, failure) {

		var LoaderObj = {};
			LoaderObj.statusInterval = 10;	
			LoaderObj.scripts = scripts;
			LoaderObj.onSuccess = success;
			LoaderObj.onFailure = failure;
			LoaderObj.timeout = 10000;
			LoaderObj.files = [];
			LoaderObj.head = document.getElementsByTagName("head")[0];

		/*Write Files in Head tag*/
		for (var i=0; i<scripts.length; i++) {
			
			var scriptName = scripts[i].type.toLowerCase();
			var node = null;

			//JS File
			if (scriptName == "js") {
				node = document.createElement("script");
				node.setAttribute("type","text/javascript");
				node.setAttribute("src",LoaderObj.scripts[i].file);
				node.onload = function () {this.loaded = true;};
			} 
			//CSS File
			else if (scriptName == "css") {
				node = document.createElement("link");
				node.setAttribute("type","text/css");
				node.setAttribute("rel","stylesheet");
				node.setAttribute("href",LoaderObj.scripts[i].file);
				node.onload = function () {this.loaded = true;};
			}
			//BOTH
			if (scriptName == "js" || scriptName == "css") {
				LoaderObj.head.appendChild(node);
				LoaderObj.files.push({
					node:node, 
					file:scripts[i].file, 
					type:scripts[i].type, 
					loaded:false, 
					elphased:0,
					stopped:false
				});
			}
		}

		//If there is any resource to load then load it
		if (LoaderObj.files.length > 0 ) {
			(function (Loader) {
				Loader.timerId = window.setInterval(function () {
					var pendingCount = 0;
					var loadedCount = 0;

					for (var i=0; i<Loader.files.length; i++) {
						
						//IF not loaded and not timeout then recheck status
						if (Loader.files[i].elphased <= Loader.timeout) {
							
							if (Loader.files[i].loaded == false ) {
								if (Loader.files[i].node.loaded) {
									Loader.files[i].loaded = true;
								}
								Loader.files[i].elphased += Loader.statusInterval;
							} 
						}

						if (Loader.files[i].loaded == true) {
							loadedCount ++;
						} else if (Loader.files[i].loaded == false && Loader.files[i].elphased <= Loader.timeout)  {
							pendingCount ++;
						}
					}

					//If no script is pending then stop timer
					if (pendingCount == 0) {
						window.clearInterval(Loader.timerId);
						if (loadedCount == Loader.files.length) 
							Loader.onSuccess();
						else 
							Loader.onFailure();
					}
			}, Loader.statusInterval);

		}) (LoaderObj);
	}
	}
};
