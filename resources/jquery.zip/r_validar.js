/*
 data - dd/MM/yyyy
 retorno
 true  -	data v�lida.
 false - data inv�lida.
 */

function validarData(data) {
	var patternData = /^(((0[1-9]|[12][0-9]|3[01])([-.\/])(0[13578]|10|12)([-.\/])(\d{4}))|(([0][1-9]|[12][0-9]|30)([-.\/])(0[469]|11)([-.\/])(\d{4}))|((0[1-9]|1[0-9]|2[0-8])([-.\/])(02)([-.\/])(\d{4}))|((29)(\.|-|\/)(02)([-.\/])([02468][048]00))|((29)([-.\/])(02)([-.\/])([13579][26]00))|((29)([-.\/])(02)([-.\/])([0-9][0-9][0][48]))|((29)([-.\/])(02)([-.\/])([0-9][0-9][2468][048]))|((29)([-.\/])(02)([-.\/])([0-9][0-9][13579][26])))$/;
	return patternData.test(data);
}
/*
 * strCPF
 * 
 * retorno true - cpf v�lido false - cpf inv�lido
 */

function testaCPF(strCPF) {

	strCPF = strCPF.replace(/\.|\-/g, '');
	

	var Soma;
	var Resto;
	Soma = 0;
	if (strCPF == "00000000000"|| strCPF == "11111111111" || strCPF == "22222222222" ||
			strCPF == "33333333333" || strCPF == "44444444444" || strCPF == "55555555555" 
			|| strCPF == "66666666666" || strCPF == "77777777777" ||strCPF == "88888888888" 
			|| strCPF == "99999999999")
		return false;
	for (i = 1; i <= 9; i++)
		Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
	Resto = (Soma * 10) % 11;
	if ((Resto == 10) || (Resto == 11))
		Resto = 0;
	if (Resto != parseInt(strCPF.substring(9, 10)))
		return false;
	Soma = 0;
	for (i = 1; i <= 10; i++)
		Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
	Resto = (Soma * 10) % 11;
	if ((Resto == 10) || (Resto == 11))
		Resto = 0;
	if (Resto != parseInt(strCPF.substring(10, 11)))
		return false;
	return true;
}

function popupPdf(url) {
	//alert('Attention: The document will be opened in another window. Please close window after printing or viewing!');
	var attributes = 'menubar=no,toolbar=no,scrollbars=yes,resizable=yes,fullscreen=no';
	//attributes = attributes + ',width=' + (screen.availWidth - 1000);
	//attributes = attributes + ',height=' + (screen.availHeight - 700);
	//attributes = attributes + ',screenX=50,screenY=50,left=10,top=10';
	var wOpen;
	wOpen = window.open(url, 'theChild', attributes);
	
	wOpen = 	window.open	(	pURL,
			"",	
			"resizable=no,status=no,"+
			"scrollbars=yes"+
			",width=20"+
			",height=150"+
			",left=90"+
			",top=60");
	
	
	

	wOpen.focus();
	wOpen.moveTo(75, 50);
	wOpen.resizeTo(screen.availWidth, screen.availHeight);

	return wOpen;

}

var theChild;
function showPdf(url) {
	if (theChild != null) {
		//if (getCurrentBrowserName() != 'msie') {
			theChild.close();
		//}
	}
	theChild = popupPdf(url);
	//theChild.focus();
}


function validacaoEmail(field) 
{ 	usuario = field.value.substring(0, field.value.indexOf("@")); 
	dominio = field.value.substring(field.value.indexOf("@")+ 1, field.value.length); 
	if ((usuario.length >=1) && (dominio.length >=3) && (usuario.search("@")==-1) && (dominio.search("@")==-1) && (usuario.search(" ")==-1) && (dominio.search(" ")==-1) && (dominio.search(".")!=-1) && (dominio.indexOf(".") >=1)&& (dominio.lastIndexOf(".") < dominio.length - 1)) { 
		return true;
	} 
	else{ 
		return false;
	} 
}
