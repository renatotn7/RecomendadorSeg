/**
  * Método que substiui a url do Certificado pela url Certificado Mais Proteção/Superprotegido abrindo a mesma em uma nova janela (pop-pup) 
  * caso esteja na lista de apólices super-protegidas (listaMaisProtecao)
  * 
  * Exemplo:
  * 
  * $('a[href=/SVGB-PIVI/menu-servicos-view.do?path=/SVGB-PIVI/certificado/consultar/consulta-certificado-individual-view.do]')
		.tratarSuperProtegido(<c:out value="${sessionScope.listaMaisProtecao}" escapeXml="false" />);
  *  
 */
$.fn.tratarSuperProtegido = function(listaMaisProtecao){
	var apolice 		= $('#numeroApoliceSelecionada').val();	 // localizado na página [inc-dados-selecionados-dropdown.jsp]	
	var url				= $(this);					
	var urlCertificado 	= url.attr('href');		
	for (x in listaMaisProtecao) {
		if(apolice===listaMaisProtecao[x]){
			url.attr('href','#/SVGB-PIVI/certificado/consultar/certificado-impressao.do?tpAE=S');
		}		
	}
};

function confirmarInclusao(){	
	var count = 0;
	var cod = 0;
	var form = document.forms[0];
	$("#funcionalidadesSelecionadas option").each(function(){
	  $(this).attr("selected","selected");		  
	});

	$("#listaFuncionalidades option").each(function(){
	  $(this).attr("selected","");
	});

	$("#produtosSelecionados option").each(function(){
	  $(this).attr("selected","selected");
	});

	form.action= '/SVGB-PIVI/liberacaoAcessoSegurado/liberacaoAcessoIncluirSubGrupos.do';
	if (validarInclusaoApol($('#produtosSelecionados option:selected[value!=-1]'))){
	    if(validarInclusaoFuncs($('#funcionalidadesSelecionadas option:selected[value!=-1]'))){
	       form.submit();
	    }
	}
}

function validarInclusaoApol(pApolices){
	var valor= $(pApolices).length;
	if(valor > 0 ){
		return true;
	}else{
		alert('Selecione uma Ap�lice');
		return false;
	}
}

function validarInclusaoFuncs(pfuncs){
	var valor= $(pfuncs).length;
	if(valor > 0 ){
		return true;
	}else{
		alert('Selecione uma Funcionalidade');
		return false;
	}
}

function confirmarExcluir(){
	var count = 0;
	var cod = 0;
	var form = document.forms[0];
	form.action= '/SVGB-PIVI/liberacaoAcessoSegurado/liberacaoAcessoExcluirSubGrupos.do';
	form.submit();
}

function excluirSubGrupo(chvNegocioRet, nomeSubGrupo){
	var form = document.forms[0];
	var codGrupo = document.getElementById('codGrupo');
	var agree = confirm('Voc� optou por excluir o subgrupo ' + nomeSubGrupo + '\nEsta a��o ir� excluir os subgrupos dos seus administradores. \nTem certeza que deseja continuar?');
	if(agree){
		form.action = "/SVGB-PIVI/grupo/alterar/grupo-excluir-sub-grupos.do?chvNegocioRet=" + chvNegocioRet + '&codGrupo=' + codGrupo.value;
		form.submit();
	}
}

function obterFuncApolice(pApolices){
		limparFuncionalidades();		
		var url_func = '/SVGB-PIVI/liberacaoAcessoSegurado/obterListaFuncionalidadesAjax.do'
		$(pApolices).each(
			function(count){
				if(count==0){
					url_func+='?apol='+this.value;
				}else{
					url_func+='&apol='+this.value;
				}
			}
		);
		try{
			$.ajax({
				dataType:"json",
				url: url_func,
				success:function(param){
					for(i in param["data"]){
						// REMOVER
						$('#listaFuncionalidades option[value='+param["data"][i]["id"]+']').remove();
						//$('#listaFuncionalidades option[value='+param["data"][i]["id"]+']'> option:selected[value!=-1]).remove();
						// ADICIONAR
						$('#funcionalidadesSelecionadas').append("<option value='"+param['data'][i]['id']+"'>"+param['data'][i]['label']+"</option>");
					}
					$('#listaFuncionalidades').prepend('<option value="-1">Todos</option>');
				}
		});
		}catch(e){
		}
	}
function limparFuncionalidades(){
	
		//$("select[id='funcionalidadesSelecionadas'] > option:selected[value!=-1]").remove();
	//	$('funcionalidadesSelecionadas').prepend('<option value="-1">Todos</option>');
	$("select[id='funcionalidadesSelecionadas']").empty();
	
		
			
	}


function associarProduto(){
		var total = $('#produtosSelecionados option[value!=-1]').length + $('#listaApolices_ option:selected[value!=-1]').length;
		if($('#listaApolices_ option:selected').length==0){
		   alert("N�o h� produtos a serem selecionados.");
		}else
		   if($('#listaApolices_ option:selected').length==1&&
			  $('#listaApolices_ option:selected').get(0).value=='-1'){
			  if($('#listaApolices_ option').length>TOTAL_LIMITE_PROD){
				 alert(MSG_LIMITE_PROD);
				 return;
			  }
			  $('#produtosSelecionados').append($('#listaApolices_ option[value!=-1]'));
			  sortList('produtosSelecionados');
			  sortList('listaApolices_');
		   }else 
		      if($('#listaApolices_ option:selected').get(0).value!=-1){
			     $('#produtosSelecionados').append($('#listaApolices_ option:selected[value!=-1]'));
			     sortList('produtosSelecionados');
			     sortList('listaApolices_');
		      }else{
		         alert("Seleciona algum produto.");
		      }
		if($('#produtosSelecionados option').length>1){
			$('#tipoBuscaProd').attr('checked','checked');
			$('#nomeDoGrupo').val('');
		}else{
			$('#tipoBuscaProd').removeAttr('checked');
		}
		obterFuncApolice($('#produtosSelecionados option[value!=-1]'));
	}

	function desassociarProduto(){
		if($('#produtosSelecionados option:selected').length==0){
			alert("N�o h� produtos a serem selecionados.");
		}else if($('#produtosSelecionados option:selected').length==1 && $('#produtosSelecionados option:selected').get(0).value=='-1'){
			     $('#listaApolices_').append($('#produtosSelecionados option[value!=-1]'));
			     sortList('produtosSelecionados');
			     sortList('listaApolices_');
		      }else 
		         if($('#produtosSelecionados option:selected').get(0).value!=-1) {
			        $('#listaApolices_').append($('#produtosSelecionados option:selected[value!=-1]'));
			        sortList('produtosSelecionados');
			        sortList('listaApolices_');
		         }else{
			        alert("Seleciona algum produto.");
		         }
		if($('#produtosSelecionados option').length>1){
			$('#tipoBuscaProd').attr('checked','checked');
		}else{
			$('#tipoBuscaProd').removeAttr('checked');
		}		
		$('#funcionalidadesSelecionadas option').attr('selected','selected');		
		desassociarFuncionalidadeProduto();
		obterFuncApolice($('#produtosSelecionados option[value!=-1]'));		
	}
 function associarFuncionalidade(){
	var total = $('#funcionalidadesSelecionadas option[value!=-1]').length + $('#listaFuncionalidades option:selected[value!=-1]').length;
	if($('#listaFuncionalidades option:selected').length==0){
		alert("N�o h� funcionalidades a serem selecionadas.");
	}else if($('#listaFuncionalidades option:selected').length==1&&
			 $('#listaFuncionalidades option:selected').get(0).value=='-1'){
		     if($('#listaFuncionalidades option').length>TOTAL_LIMITE_PROD){
			    alert(MSG_LIMITE_PROD);
			    return;
		     }
		     $('#funcionalidadesSelecionadas').append($('#listaFuncionalidades option[value!=-1]'));
		     sortList('funcionalidadesSelecionadas');
		     sortList('listaFuncionalidades');
	      }else if($('#listaFuncionalidades option:selected').get(0).value!=-1){
			       $('#funcionalidadesSelecionadas').append($('#listaFuncionalidades option:selected[value!=-1]'));
		           sortList('funcionalidadesSelecionadas');
		           sortList('listaFuncionalidades');
	            }else{
		           alert("Seleciona alguma funcionalidade.");
	            }
	if($('#funcionalidadesSelecionadas option').length>1){
		$('#tipoBuscaProd').attr('checked','checked');
		//document.forms[0].tipoBuscaIni[1].checked=true;
		$('#nomeDoGrupo').val('');
	}else{
		$('#tipoBuscaProd').removeAttr('checked');
	}
}

function desassociarFuncionalidade(){
	if($('#funcionalidadesSelecionadas option:selected').length==0){
	   alert("N�o h� funcionalidades a serem selecionadas.");
	}else if($('#funcionalidadesSelecionadas option:selected').length==1&&
			 $('#funcionalidadesSelecionadas option:selected').get(0).value=='-1'){
		     $('#listaFuncionalidades').append($('#funcionalidadesSelecionadas option[value!=-1]'));
		     sortList('funcionalidadesSelecionadas');
		     sortList('listaFuncionalidades');
	      }else
	         if($('#funcionalidadesSelecionadas option:selected').get(0).value!=-1){
		        $('#listaFuncionalidades').append($('#funcionalidadesSelecionadas option:selected[value!=-1]'));
		        sortList('funcionalidadesSelecionadas');
		        sortList('listaFuncionalidades');
	         }else{
		        alert("Seleciona alguma funcionalidade.");
	         }
	if($('#funcionalidadesSelecionadas option').length>1){
		$('#tipoBuscaProd').attr('checked','checked');
		document.forms[0].tipoBuscaIni[1].checked=true;
	}else{
		$('#tipoBuscaProd').removeAttr('checked');
		document.forms[0].tipoBuscaIni[1].checked=false;			
	}		
}

   function confirmarExcluir(numApol,chaveApol,subFat){
	var count = 0;
	var cod = 0;
	var form = document.forms[0];
	form.action= '/SVGB-PIVI/liberacaoAcessoSegurado/liberacaoAcessoExcluirSubGrupos.do?'+'numApol='+numApol +'&chaveApol='+chaveApol+'&subFat='+subFat;
	form.submit();
}

function sortList(pId){
	$('#'+pId+' option[value=-1]').remove();
	$('#'+pId).html($('#'+pId).find('option[value!=-1]').sort(
		function (a, b){
	    	return a.text == b.text ? 0 : a.text < b.text ? -1 : 1;
	    }
	));
	if(pId!='produtosNaoSelecionados'){
		$('#'+pId).prepend('<option value="-1">Todos</option>');
	}
}

function desassociarFuncionalidadeProduto(){
		if($('#funcionalidadesSelecionadas option:selected').length==0){
		   alert("N�o h� funcionalidades a serem selecionadas.");
		}else if($('#funcionalidadesSelecionadas option:selected').length==1&&
				 $('#funcionalidadesSelecionadas option:selected').get(0).value=='-1'){
			     $('#listaFuncionalidades').append($('#funcionalidadesSelecionadas option[value!=-1]'));
			     sortList('funcionalidadesSelecionadas');
			     sortList('listaFuncionalidades');
		      }else
		         if($('#funcionalidadesSelecionadas option:selected').get(0).value=='-1'){
			        $('#listaFuncionalidades').append($('#funcionalidadesSelecionadas option:selected[value!=-1]'));
			        sortList('funcionalidadesSelecionadas');
			        sortList('listaFuncionalidades');			        
		         }else{
			        alert("Seleciona alguma funcionalidade.");
		         }
		if($('#funcionalidadesSelecionadas option').length>1){
			$('#tipoBuscaProd').attr('checked','checked');
			$('funcionalidadesSelecionadas').prepend('<option value="-1">Todos</option>');
		}else{
			$('#tipoBuscaProd').removeAttr('checked');		
			return true;			
		}
		return true;
	}
	function TrocarSubGrupoADM(){
	var fowardValue ="fwd-liberacao-acesso-adm";
		//chama a fun��o de troca de SubGrupo
		subGrupoOnChangeAdm(fowardValue);
	}
	function TrocarApoliceEst(){
	var fowardValue ="fwd-liberacao-acesso-adm";
		//chama a fun��o de troca de ap�lice para Estipulante
		apoliceOnChange(fowardValue);
	}
	
	function TrocarSubGrupoEst(opt){
	var fowardValue ="fwd-liberacao-acesso-adm";
		//chama a fun��o de troca de SubGrupo para Estipulante
		subGrupoOnChange(opt,fowardValue);
	}